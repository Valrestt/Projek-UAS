<?php
return array(
    'host'     => 'localhost',
    'database' => 'db_sales_order',
    'username' => 'root',
    'password' => '',
    'charset'  => 'utf8mb4'
);
