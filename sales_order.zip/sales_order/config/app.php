<?php
return array(
    'app_name' => 'Sistem Sales Order',
    // Kosongkan agar base URL otomatis mengikuti nama folder di htdocs.
    // Contoh akses: http://localhost/sales_order_final/
    'base_url' => ''
);
