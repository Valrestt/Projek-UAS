<?php
class DashboardController extends Controller
{
    public function index()
    {
        Middleware::requireLogin();

        $laporan = new LaporanModel();
        $order = new OrderModel();
        $user = Middleware::user();

        $orders = array();
        if ($user['role'] !== 'Manager') {
            $orders = $order->allByRole($user['role'], $user['id_sales']);
        }

        $this->view('dashboard/index', array(
            'title' => 'Dashboard',
            'cards' => $laporan->cards(),
            'orders' => array_slice($orders, 0, 5)
        ));
    }
}
