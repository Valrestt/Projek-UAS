<?php
class SalesController extends Controller
{
    private $model;

    public function __construct()
    {
        Middleware::requireRole(array('Admin'));
        $this->model = new UserModel();
    }

    public function index()
    {
        $this->view('sales/index', array(
            'title' => 'Data User / Sales Person',
            'users' => $this->model->all()
        ));
    }

    public function create()
    {
        $this->view('sales/form', array('title' => 'Tambah User', 'userData' => null));
    }

    public function store()
    {
        $this->verifyCsrf();
        $data = array(
            'nama'     => $this->request('nama'),
            'username' => $this->request('username'),
            'password' => $this->request('password'),
            'role'     => $this->request('role')
        );

        if ($data['nama'] === '' || $data['username'] === '' || $data['password'] === '') {
            set_flash('error', 'Nama, username, dan password wajib diisi.');
            set_old($data);
            redirect_url('sales/create');
        }

        try {
            $this->model->create($data);
            set_flash('success', 'User berhasil ditambahkan.');
        } catch (Exception $e) {
            set_flash('error', 'Gagal menyimpan user. Username mungkin sudah digunakan.');
        }
        redirect_url('sales');
    }

    public function edit()
    {
        $id = (int) $this->request('id');
        $userData = $this->model->find($id);
        if (!$userData) {
            set_flash('error', 'User tidak ditemukan.');
            redirect_url('sales');
        }
        $this->view('sales/form', array('title' => 'Edit User', 'userData' => $userData));
    }

    public function update()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');
        $data = array(
            'nama'     => $this->request('nama'),
            'username' => $this->request('username'),
            'password' => $this->request('password'),
            'role'     => $this->request('role')
        );

        try {
            $this->model->update($id, $data);
            set_flash('success', 'User berhasil diperbarui.');
        } catch (Exception $e) {
            set_flash('error', 'Gagal memperbarui user.');
        }
        redirect_url('sales');
    }

    public function delete()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');

        if ((int) Middleware::user()['id_sales'] === $id) {
            set_flash('error', 'User yang sedang login tidak boleh dihapus.');
            redirect_url('sales');
        }

        try {
            $this->model->delete($id);
            set_flash('success', 'User berhasil dihapus.');
        } catch (Exception $e) {
            set_flash('error', 'User tidak dapat dihapus karena sudah digunakan pada transaksi.');
        }
        redirect_url('sales');
    }
}
