<?php
class PelangganController extends Controller
{
    private $model;

    public function __construct()
    {
        Middleware::requireRole(array('Admin'));
        $this->model = new PelangganModel();
    }

    public function index()
    {
        $this->view('pelanggan/index', array(
            'title' => 'Data Pelanggan',
            'pelanggan' => $this->model->all()
        ));
    }

    public function create()
    {
        $this->view('pelanggan/form', array('title' => 'Tambah Pelanggan', 'pelanggan' => null));
    }

    public function store()
    {
        $this->verifyCsrf();
        $data = array(
            'nama_pelanggan' => $this->request('nama_pelanggan'),
            'alamat'         => $this->request('alamat'),
            'no_telp'        => $this->request('no_telp')
        );

        if ($data['nama_pelanggan'] === '') {
            set_flash('error', 'Nama pelanggan wajib diisi.');
            set_old($data);
            redirect_url('pelanggan/create');
        }

        $this->model->create($data);
        set_flash('success', 'Pelanggan berhasil ditambahkan.');
        redirect_url('pelanggan');
    }

    public function edit()
    {
        $id = (int) $this->request('id');
        $pelanggan = $this->model->find($id);
        if (!$pelanggan) {
            set_flash('error', 'Pelanggan tidak ditemukan.');
            redirect_url('pelanggan');
        }
        $this->view('pelanggan/form', array('title' => 'Edit Pelanggan', 'pelanggan' => $pelanggan));
    }

    public function update()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');
        $data = array(
            'nama_pelanggan' => $this->request('nama_pelanggan'),
            'alamat'         => $this->request('alamat'),
            'no_telp'        => $this->request('no_telp')
        );
        $this->model->update($id, $data);
        set_flash('success', 'Pelanggan berhasil diperbarui.');
        redirect_url('pelanggan');
    }

    public function delete()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');
        try {
            $this->model->delete($id);
            set_flash('success', 'Pelanggan berhasil dihapus.');
        } catch (Exception $e) {
            set_flash('error', 'Pelanggan tidak dapat dihapus karena sudah digunakan pada transaksi.');
        }
        redirect_url('pelanggan');
    }
}
