<?php
class LaporanController extends Controller
{
    private $model;

    public function __construct()
    {
        Middleware::requireRole(array('Admin', 'Manager'));
        $this->model = new LaporanModel();
    }

    public function index()
    {
        $start = $this->request('tanggal_awal', '');
        $end = $this->request('tanggal_akhir', '');

        $this->view('laporan/index', array(
            'title' => 'Laporan Penjualan',
            'tanggal_awal' => $start,
            'tanggal_akhir' => $end,
            'cards' => $this->model->cards($start, $end),
            'perSales' => $this->model->perSales($start, $end),
            'perProduk' => $this->model->perProduk($start, $end),
            'perPeriode' => $this->model->perPeriode($start, $end)
        ));
    }

    public function pdf()
    {
        $start = $this->request('tanggal_awal', '');
        $end = $this->request('tanggal_akhir', '');

        $cards = $this->model->cards($start, $end);
        $perSales = $this->model->perSales($start, $end);
        $perProduk = $this->model->perProduk($start, $end);
        $perPeriode = $this->model->perPeriode($start, $end);

        $pdf = new SimplePdf();
        $pdf->addLine('LAPORAN PENJUALAN - SISTEM SALES ORDER');
        $pdf->addLine('Periode: ' . ($start ? $start : '-') . ' s/d ' . ($end ? $end : '-'));
        $pdf->addLine('Total Order Selesai : ' . $cards->total_order);
        $pdf->addLine('Total Penjualan     : ' . rupiah($cards->total_penjualan));
        $pdf->addLine('');

        $pdf->addLine('PENJUALAN PER SALES');
        $pdf->addLine(str_pad('Sales', 25) . str_pad('Order', 10) . 'Total');
        foreach ($perSales as $row) {
            $pdf->addLine(str_pad(substr($row->nama_sales, 0, 24), 25) . str_pad($row->jumlah_order, 10) . rupiah($row->total_penjualan));
        }
        $pdf->addLine('');

        $pdf->addLine('PENJUALAN PER PRODUK');
        $pdf->addLine(str_pad('Produk', 35) . str_pad('Qty', 10) . 'Total');
        foreach ($perProduk as $row) {
            $namaProduk = $row->kode_produk . ' - ' . $row->nama_produk;
            $pdf->addLine(str_pad(substr($namaProduk, 0, 34), 35) . str_pad($row->jumlah_terjual, 10) . rupiah($row->total_penjualan));
        }
        $pdf->addLine('');

        $pdf->addLine('PENJUALAN PER PERIODE');
        $pdf->addLine(str_pad('Tanggal', 15) . str_pad('Order', 10) . 'Total');
        foreach ($perPeriode as $row) {
            $pdf->addLine(str_pad($row->tanggal_order, 15) . str_pad($row->jumlah_order, 10) . rupiah($row->total_penjualan));
        }

        $pdf->output('laporan-sales-order.pdf');
    }
}
