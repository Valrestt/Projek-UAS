<?php
class OrderController extends Controller
{
    private $orderModel;
    private $pelangganModel;
    private $produkModel;
    private $userModel;

    public function __construct()
    {
        Middleware::requireRole(array('Admin', 'Sales'));
        $this->orderModel = new OrderModel();
        $this->pelangganModel = new PelangganModel();
        $this->produkModel = new ProdukModel();
        $this->userModel = new UserModel();
    }

    public function index()
    {
        $user = Middleware::user();
        $this->view('orders/index', array(
            'title' => 'Sales Order',
            'orders' => $this->orderModel->allByRole($user['role'], $user['id_sales'])
        ));
    }

    public function create()
    {
        $this->view('orders/create', array(
            'title' => 'Buat Sales Order',
            'pelanggan' => $this->pelangganModel->all(),
            'produk' => $this->produkModel->available(),
            'salesList' => $this->userModel->salesOnly()
        ));
    }

    public function store()
    {
        $this->verifyCsrf();

        $user = Middleware::user();
        $idSales = $user['role'] === 'Admin' ? (int) $this->request('id_sales') : (int) $user['id_sales'];

        $header = array(
            'id_sales'      => $idSales,
            'id_pelanggan'  => (int) $this->request('id_pelanggan'),
            'tanggal_order' => $this->request('tanggal_order')
        );

        $produkPost = $this->request('id_produk', array());
        $jumlahPost = $this->request('jumlah', array());
        $items = array();

        if (is_array($produkPost)) {
            foreach ($produkPost as $i => $idProduk) {
                $items[] = array(
                    'id_produk' => $idProduk,
                    'jumlah'    => isset($jumlahPost[$i]) ? $jumlahPost[$i] : 0
                );
            }
        }

        if ($header['id_pelanggan'] <= 0 || $header['tanggal_order'] === '' || $header['id_sales'] <= 0) {
            set_flash('error', 'Tanggal, pelanggan, dan sales wajib diisi.');
            redirect_url('orders/create');
        }

        $result = $this->orderModel->create($header, $items);

        if ($result['success']) {
            set_flash('success', $result['message']);
            redirect_url('orders/detail&id=' . $result['id_order']);
        }

        set_flash('error', $result['message']);
        redirect_url('orders/create');
    }

    public function detail()
    {
        $id = (int) $this->request('id');
        $order = $this->orderModel->find($id);
        $user = Middleware::user();

        if (!$this->orderModel->canAccess($order, $user)) {
            set_flash('error', 'Order tidak ditemukan atau Anda tidak memiliki akses.');
            redirect_url('orders');
        }

        $this->view('orders/detail', array(
            'title' => 'Detail Order',
            'order' => $order,
            'details' => $this->orderModel->details($id)
        ));
    }

    public function status()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');
        $status = $this->request('status');

        $order = $this->orderModel->find($id);
        $user = Middleware::user();

        if (!$this->orderModel->canAccess($order, $user)) {
            set_flash('error', 'Anda tidak memiliki akses untuk mengubah order ini.');
            redirect_url('orders');
        }

        $this->orderModel->updateStatus($id, $status);
        set_flash('success', 'Status order berhasil diperbarui.');
        redirect_url('orders/detail&id=' . $id);
    }
}
