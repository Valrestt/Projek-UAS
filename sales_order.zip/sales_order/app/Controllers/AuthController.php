<?php
class AuthController extends Controller
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function login()
    {
        if (Middleware::isLoggedIn()) {
            redirect_url('dashboard');
        }
        $this->viewOnly('auth/login');
    }

    public function process()
    {
        $this->verifyCsrf();

        $username = $this->request('username');
        $password = $this->request('password');

        $user = $this->userModel->findByUsername($username);

        if ($user && password_verify($password, $user->password)) {
            $_SESSION['user'] = array(
                'id_sales'  => $user->id_sales,
                'nama'      => $user->nama,
                'username'  => $user->username,
                'role'      => $user->role,
                'logged_in' => true
            );
            set_flash('success', 'Login berhasil. Selamat datang, ' . $user->nama . '.');
            redirect_url('dashboard');
        }

        set_old(array('username' => $username));
        set_flash('error', 'Username atau password salah.');
        redirect_url('auth/login');
    }

    public function logout()
    {
        session_destroy();
        session_start();
        set_flash('success', 'Anda berhasil logout.');
        redirect_url('auth/login');
    }
}
