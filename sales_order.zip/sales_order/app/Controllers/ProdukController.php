<?php
class ProdukController extends Controller
{
    private $model;

    public function __construct()
    {
        Middleware::requireRole(array('Admin'));
        $this->model = new ProdukModel();
    }

    public function index()
    {
        $this->view('produk/index', array(
            'title' => 'Data Produk',
            'produk' => $this->model->all()
        ));
    }

    public function create()
    {
        $this->view('produk/form', array('title' => 'Tambah Produk', 'produk' => null));
    }

    public function store()
    {
        $this->verifyCsrf();
        $data = array(
            'kode_produk' => $this->request('kode_produk'),
            'nama_produk' => $this->request('nama_produk'),
            'harga'       => (float) $this->request('harga'),
            'stok'        => (int) $this->request('stok')
        );

        if ($data['kode_produk'] === '' || $data['nama_produk'] === '') {
            set_flash('error', 'Kode dan nama produk wajib diisi.');
            set_old($data);
            redirect_url('produk/create');
        }

        try {
            $this->model->create($data);
            set_flash('success', 'Produk berhasil ditambahkan.');
        } catch (Exception $e) {
            set_flash('error', 'Gagal menyimpan produk. Kode produk mungkin sudah digunakan.');
        }
        redirect_url('produk');
    }

    public function edit()
    {
        $id = (int) $this->request('id');
        $produk = $this->model->find($id);
        if (!$produk) {
            set_flash('error', 'Produk tidak ditemukan.');
            redirect_url('produk');
        }
        $this->view('produk/form', array('title' => 'Edit Produk', 'produk' => $produk));
    }

    public function update()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');
        $data = array(
            'kode_produk' => $this->request('kode_produk'),
            'nama_produk' => $this->request('nama_produk'),
            'harga'       => (float) $this->request('harga'),
            'stok'        => (int) $this->request('stok')
        );
        try {
            $this->model->update($id, $data);
            set_flash('success', 'Produk berhasil diperbarui.');
        } catch (Exception $e) {
            set_flash('error', 'Gagal memperbarui produk.');
        }
        redirect_url('produk');
    }

    public function delete()
    {
        $this->verifyCsrf();
        $id = (int) $this->request('id');
        try {
            $this->model->delete($id);
            set_flash('success', 'Produk berhasil dihapus.');
        } catch (Exception $e) {
            set_flash('error', 'Produk tidak dapat dihapus karena sudah digunakan pada transaksi.');
        }
        redirect_url('produk');
    }
}
