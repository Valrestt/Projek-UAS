<div class="page-header">
    <div>
        <h1><?php echo e($title); ?></h1>
        <p>Isi informasi pelanggan.</p>
    </div>
</div>

<?php $isEdit = !empty($pelanggan); ?>
<form class="card form" method="post" action="<?php echo e($isEdit ? url('pelanggan/update') : url('pelanggan/store')); ?>">
    <?php echo csrf_input(); ?>
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?php echo e($pelanggan->id_pelanggan); ?>">
    <?php endif; ?>

    <label>Nama Pelanggan</label>
    <input type="text" name="nama_pelanggan" value="<?php echo e($isEdit ? $pelanggan->nama_pelanggan : old('nama_pelanggan')); ?>" required>

    <label>Alamat</label>
    <textarea name="alamat" rows="4"><?php echo e($isEdit ? $pelanggan->alamat : old('alamat')); ?></textarea>

    <label>No. Telp</label>
    <input type="text" name="no_telp" value="<?php echo e($isEdit ? $pelanggan->no_telp : old('no_telp')); ?>">

    <div class="form-actions">
        <a class="btn secondary" href="<?php echo e(url('pelanggan')); ?>">Kembali</a>
        <button class="btn" type="submit">Simpan</button>
    </div>
</form>
