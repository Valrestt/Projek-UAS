<div class="page-header">
    <div>
        <h1><?php echo e($title); ?></h1>
        <p>Kelola akun pengguna sistem.</p>
    </div>
</div>

<?php $isEdit = !empty($userData); ?>
<form class="card form" method="post" action="<?php echo e($isEdit ? url('sales/update') : url('sales/store')); ?>">
    <?php echo csrf_input(); ?>
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?php echo e($userData->id_sales); ?>">
    <?php endif; ?>

    <label>Nama</label>
    <input type="text" name="nama" value="<?php echo e($isEdit ? $userData->nama : old('nama')); ?>" required>

    <label>Username</label>
    <input type="text" name="username" value="<?php echo e($isEdit ? $userData->username : old('username')); ?>" required>

    <label>Password <?php echo $isEdit ? '<small>kosongkan jika tidak diubah</small>' : ''; ?></label>
    <input type="password" name="password" <?php echo $isEdit ? '' : 'required'; ?>>

    <label>Role</label>
    <?php $roleValue = $isEdit ? $userData->role : old('role', 'Sales'); ?>
    <select name="role" required>
        <option value="Admin" <?php echo selected($roleValue, 'Admin'); ?>>Admin</option>
        <option value="Sales" <?php echo selected($roleValue, 'Sales'); ?>>Sales</option>
        <option value="Manager" <?php echo selected($roleValue, 'Manager'); ?>>Manager</option>
    </select>

    <div class="form-actions">
        <a class="btn secondary" href="<?php echo e(url('sales')); ?>">Kembali</a>
        <button class="btn" type="submit">Simpan</button>
    </div>
</form>
