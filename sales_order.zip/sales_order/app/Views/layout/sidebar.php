<?php if (!empty($current_user)): ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

<style>
    /* ========== SIDEBAR MODERN DENGAN WARNA IKON ========== */
    .sidebar {
        width: 280px;
        min-height: 100vh;
        background: rgba(15, 23, 42, 0.95);
        backdrop-filter: blur(12px);
        color: #f1f5f9;
        padding: 28px 20px;
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        font-family: 'Inter', 'Poppins', sans-serif;
        z-index: 100;
        border-right: 1px solid rgba(255, 255, 255, 0.08);
    }

    .brand {
        display: flex;
        align-items: center;
        gap: 14px;
        margin-bottom: 40px;
        padding-bottom: 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.1);
    }

    .brand-logo {
        width: 52px;
        height: 52px;
        border-radius: 18px;
        background: linear-gradient(135deg, #3b82f6, #8b5cf6);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        color: white;
        box-shadow: 0 10px 20px -5px rgba(59,130,246,0.5);
    }

    .brand strong {
        display: block;
        font-size: 1.1rem;
        font-weight: 700;
    }

    .brand span {
        color: #94a3b8;
        font-size: 0.7rem;
    }

    .menu {
        display: flex;
        flex-direction: column;
        gap: 8px;
        margin-top: 10px;
    }

    .menu a {
        display: flex;
        align-items: center;
        gap: 14px;
        padding: 12px 18px;
        border-radius: 16px;
        text-decoration: none;
        font-weight: 500;
        font-size: 0.9rem;
        transition: all 0.25s;
        color: #cbd5e1;
    }

    /* ========== FIX WARNA IKON BERDASARKAN CLASS (AMAN UNTUK ROLE HIDE) ========== */
    .menu a.menu-dashboard i { color: #3b82f6; }   /* Dashboard - Biru */
    .menu a.menu-produk i { color: #10b981; }      /* Data Produk - Hijau */
    .menu a.menu-pelanggan i { color: #f59e0b; }   /* Data Pelanggan - Orange */
    .menu a.menu-sales i { color: #ec489a; }       /* Data Sales/User - Pink */
    .menu a.menu-orders i { color: #8b5cf6; }      /* Sales Order - Ungu */
    .menu a.menu-laporan i { color: #14b8a6; }     /* Laporan - Teal */

    .menu a i {
        width: 24px;
        font-size: 1.2rem;
        text-align: center;
        transition: 0.2s;
    }

    .menu a:hover {
        background: rgba(255, 255, 255, 0.08);
        color: white;
        transform: translateX(6px);
    }

    .menu a:hover i {
        color: white !important;
        transform: scale(1.05);
    }

    .menu a.active {
        background: linear-gradient(95deg, #3b82f6, #4f46e5);
        color: white;
        box-shadow: 0 8px 20px rgba(59, 130, 246, 0.4);
        transform: translateX(8px);
    }

    .menu a.active i {
        color: white !important;
        text-shadow: 0 0 3px rgba(255,255,255,0.5);
    }

    .content {
        margin-left: 280px;
        padding: 30px 35px;
        min-height: 100vh;
        background: #f8fafc;
    }

    .alert {
        padding: 14px 20px;
        border-radius: 20px;
        margin-bottom: 24px;
        font-weight: 500;
    }

    .alert.success {
        background: #dcfce7;
        color: #166534;
        border-left: 5px solid #10b981;
    }

    .alert.error {
        background: #fee2e2;
        color: #991b1b;
        border-left: 5px solid #ef4444;
    }

    @media (max-width: 900px) {
        .sidebar {
            position: relative;
            width: 100%;
            min-height: auto;
            padding: 20px;
        }
        .content {
            margin-left: 0;
            padding: 20px;
        }
        .menu a.active {
            transform: translateX(4px);
        }
    }
</style>

<aside class="sidebar">
    <div class="brand">
        <div class="brand-logo"><i class="fas fa-chart-line"></i></div>
        <div><strong>Sales Order</strong><span>PT Maju Jaya</span></div>
    </div>
    <?php $current_page = isset($_GET['r']) ? $_GET['r'] : 'dashboard'; ?>
    <nav class="menu">
        <!-- Dashboard diakses semua role (termasuk Sales dan Manager) -->
        <a href="<?php echo e(url('dashboard')); ?>" class="menu-dashboard <?php echo ($current_page == 'dashboard') ? 'active' : ''; ?>"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
        
        <?php 
        // 1. Ambil data role secara aman, baik berupa Array maupun Object
        $user_role = '';
        if (is_array($current_user) && isset($current_user['role'])) {
            $user_role = $current_user['role'];
        } elseif (is_object($current_user) && isset($current_user->role)) {
            $user_role = $current_user->role;
        }

        // 2. Ubah string menjadi huruf kecil semua agar pengecekan lebih akurat
        $role_clean = strtolower(trim($user_role));
        $is_sales   = ($role_clean === 'sales');
        $is_manager = ($role_clean === 'manager');
        ?>

        <!-- Data Produk, Data Pelanggan, Data Sales/User: 
             Disembunyikan jika user adalah SALES atau MANAGER (Hanya muncul untuk Admin/Superadmin) -->
        <?php if (!$is_sales && !$is_manager): ?>
            <a href="<?php echo e(url('produk')); ?>" class="menu-produk <?php echo ($current_page == 'produk') ? 'active' : ''; ?>"><i class="fas fa-boxes"></i> Data Produk</a>
            <a href="<?php echo e(url('pelanggan')); ?>" class="menu-pelanggan <?php echo ($current_page == 'pelanggan') ? 'active' : ''; ?>"><i class="fas fa-users"></i> Data Pelanggan</a>
            <a href="<?php echo e(url('sales')); ?>" class="menu-sales <?php echo ($current_page == 'sales') ? 'active' : ''; ?>"><i class="fas fa-user-tie"></i> Data Sales/User</a>
        <?php endif; ?>

        <!-- Sales Order:
             Disembunyikan jika user adalah MANAGER (Muncul untuk Sales dan Admin) -->
        <?php if (!$is_manager): ?>
            <a href="<?php echo e(url('orders')); ?>" class="menu-orders <?php echo ($current_page == 'orders') ? 'active' : ''; ?>"><i class="fas fa-shopping-cart"></i> Sales Order</a>
        <?php endif; ?>
        
        <!-- Laporan:
             Disembunyikan jika user adalah SALES (Muncul untuk Manager dan Admin) -->
        <?php if (!$is_sales): ?>
            <a href="<?php echo e(url('laporan')); ?>" class="menu-laporan <?php echo ($current_page == 'laporan') ? 'active' : ''; ?>"><i class="fas fa-file-alt"></i> Laporan</a>
        <?php endif; ?>
    </nav>
    </nav>
</aside>

<main class="content">

<?php else: ?>
<main class="content full">
<?php endif; ?>

<?php if (!empty($flash)): ?>
    <div class="alert <?php echo e($flash['type']); ?>"><?php echo e($flash['message']); ?></div>
<?php endif; ?>