<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Sales Order | <?php echo e($app_name ?? 'Sales Order'); ?></title>
    <!-- Google Fonts + Font Awesome -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ----- RESET & GLOBAL ----- */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f4ff, #e9f0fa, #fef2f8, #e6f7f0);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            min-height: 100vh;
            padding: 30px 35px;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 0%; }
            25% { background-position: 100% 0%; }
            50% { background-position: 100% 100%; }
            75% { background-position: 0% 100%; }
            100% { background-position: 0% 0%; }
        }

        /* Noise overlay lembut */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJmIj48ZmVUdXJidWxlbmNlIHR5cGU9ImZyYWN0YWxOb2lzZSIgYmFzZUZyZXF1ZW5jeT0iLjciIG51bU9jdGF2ZXM9IjMiLz48L2ZpbHRlcj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWx0ZXI9InVybCgjZikiIG9wYWNpdHk9IjAuMDYiLz48L3N2Zz4=');
            background-repeat: repeat;
            pointer-events: none;
            z-index: 0;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
        }

        /* ----- HEADER ----- */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            padding: 20px 28px;
            border-radius: 32px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.6);
            transition: all 0.2s;
        }

        .page-header:hover {
            box-shadow: 0 25px 45px -12px rgba(0,0,0,0.15);
        }

        .page-header h1 {
            font-size: 1.9rem;
            font-weight: 800;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 4px;
        }

        .page-header p {
            color: #4a627a;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 500;
        }

        .page-header p i {
            color: #3b82f6;
        }

        /* Tombol Buat Order */
        .btn-add {
            background: linear-gradient(135deg, #3b82f6, #1e3a8a);
            color: white;
            border: none;
            padding: 12px 28px;
            border-radius: 40px;
            font-weight: 700;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: all 0.25s;
            box-shadow: 0 12px 20px -8px rgba(59,130,246,0.4);
            letter-spacing: 0.3px;
        }

        .btn-add i {
            font-size: 1.2rem;
        }

        .btn-add:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 30px -10px rgba(59,130,246,0.6);
            background: linear-gradient(135deg, #2563eb, #1e3a8a);
        }

        /* ----- TABEL ----- */
        .table-wrap {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(12px);
            border-radius: 32px;
            padding: 20px 0 20px 0;
            box-shadow: 0 25px 45px -12px rgba(0,0,0,0.15);
            border: 1px solid rgba(255,255,255,0.6);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            font-size: 0.9rem;
        }

        th {
            padding: 18px 20px;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            color: white;
            font-weight: 600;
            text-align: left;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            letter-spacing: 0.5px;
            font-size: 0.8rem;
            text-transform: uppercase;
        }

        th i {
            margin-right: 8px;
            opacity: 0.8;
        }

        th:first-child { border-radius: 20px 0 0 20px; }
        th:last-child { border-radius: 0 20px 20px 0; }

        tbody tr {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            transition: all 0.2s;
            box-shadow: 0 12px 20px -10px rgba(0,0,0,0.08);
        }

        tbody tr:hover {
            transform: translateY(-3px);
            background: white;
            box-shadow: 0 22px 35px -12px rgba(0,0,0,0.2);
            cursor: default;
        }

        td {
            padding: 16px 20px;
            color: #1e2f3e;
            font-weight: 500;
        }

        td:first-child {
            border-top-left-radius: 16px;
            border-bottom-left-radius: 16px;
        }
        td:last-child {
            border-top-right-radius: 16px;
            border-bottom-right-radius: 16px;
        }

        /* ----- BADGE STATUS ----- */
        .status-badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: capitalize;
            letter-spacing: 0.3px;
        }

        .status-badge.draft,
        .status-badge.DRAFT {
            background: #ffedd5;
            color: #b45309;
            border-left: 4px solid #f97316;
        }

        .status-badge.dikirim,
        .status-badge.DIKIRIM,
        .status-badge.sent {
            background: #dbeafe;
            color: #1e40af;
            border-left: 4px solid #3b82f6;
        }

        .status-badge.selesai,
        .status-badge.SELESAI,
        .status-badge.completed {
            background: #d1fae5;
            color: #065f46;
            border-left: 4px solid #10b981;
        }

        .status-badge.dibatalkan,
        .status-badge.DIBATALKAN,
        .status-badge.canceled {
            background: #fee2e2;
            color: #b91c1c;
            border-left: 4px solid #ef4444;
        }

        /* ----- TOMBOL DETAIL ----- */
        .btn-detail {
            background: #eef2ff;
            color: #1e40af;
            border-left: 3px solid #3b82f6;
            padding: 6px 18px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }

        .btn-detail i {
            font-size: 0.85rem;
        }

        .btn-detail:hover {
            background: #3b82f6;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 14px rgba(59,130,246,0.3);
            border-left-color: #1e3a8a;
        }

        /* ----- EMPTY STATE ----- */
        .empty {
            text-align: center;
            padding: 60px 20px;
            color: #5b7f95;
            font-style: italic;
            font-weight: 500;
        }

        .empty i {
            display: block;
            font-size: 2.5rem;
            margin-bottom: 12px;
            opacity: 0.4;
        }

        /* ----- RESPONSIVE ----- */
        @media (max-width: 768px) {
            body {
                padding: 20px;
            }

            .page-header {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
                text-align: center;
                padding: 18px 20px;
            }

            .page-header h1 {
                font-size: 1.5rem;
            }

            .btn-add {
                justify-content: center;
                padding: 12px 20px;
                font-size: 0.9rem;
            }

            th,
            td {
                padding: 12px 14px;
                font-size: 0.8rem;
            }

            tbody tr {
                display: block;
                margin-bottom: 16px;
                border-radius: 20px;
                box-shadow: 0 8px 18px -8px rgba(0,0,0,0.12);
            }

            td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 10px 16px;
                border-bottom: 1px solid rgba(0,0,0,0.04);
            }

            td:last-child {
                border-bottom: none;
            }

            td::before {
                content: attr(data-label);
                font-weight: 600;
                color: #4a627a;
                font-size: 0.7rem;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            }

            /* Sembunyikan header tabel di mobile */
            thead {
                display: none;
            }

            .status-badge {
                font-size: 0.7rem;
                padding: 4px 12px;
            }

            .btn-detail {
                font-size: 0.7rem;
                padding: 4px 14px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="page-header">
        <div>
            <h1><i class="fas fa-shopping-cart" style="margin-right: 10px; color: #3b82f6;"></i> Sales Order</h1>
            <p><i class="fas fa-list-ul"></i> Daftar transaksi sales order.</p>
        </div>
        <a class="btn-add" href="<?php echo e(url('orders/create')); ?>">
            <i class="fas fa-plus-circle"></i> Buat Order
        </a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-hashtag"></i> No Order</th>
                    <th><i class="fas fa-calendar-alt"></i> Tanggal</th>
                    <th><i class="fas fa-user-tie"></i> Sales</th>
                    <th><i class="fas fa-building"></i> Pelanggan</th>
                    <th><i class="fas fa-money-bill-wave"></i> Total</th>
                    <th><i class="fas fa-flag-checkered"></i> Status</th>
                    <th><i class="fas fa-cog"></i> Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td data-label="No Order"><strong><?php echo e($order->no_order); ?></strong></td>
                    <td data-label="Tanggal"><?php echo e($order->tanggal_order); ?></td>
                    <td data-label="Sales"><?php echo e($order->nama_sales); ?></td>
                    <td data-label="Pelanggan"><?php echo e($order->nama_pelanggan); ?></td>
                    <td data-label="Total"><?php echo e(rupiah($order->total_harga)); ?></td>
                    <td data-label="Status"><span class="status-badge <?php echo e(strtolower($order->status)); ?>"><?php echo e($order->status); ?></span></td>
                    <td data-label="Aksi">
                        <a class="btn-detail" href="<?php echo e(url('orders/detail&id=' . $order->id_order)); ?>">
                            <i class="fas fa-eye"></i> Detail
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($orders)): ?>
                <tr>
                    <td colspan="7" class="empty">
                        <i class="fas fa-database"></i>
                        Belum ada order. Silakan buat order baru.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>