<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://unpkg.com/lucide@latest"></script>

<script>
    // Konfigurasi Custom Palet Warna agar Lebih Vibrant
    tailwind.config = {
        theme: {
            extend: {
                fontFamily: {
                    sans: ['Inter', 'sans-serif'],
                },
                colors: {
                    vibrant: {
                        teal: '#06b6d4',
                        blue: '#3b82f6',
                        indigo: '#6366f1',
                    }
                }
            }
        }
    }
</script>

<style>
    /* Menghilangkan panah spinner default pada input number */
    input[type=number]::-webkit-inner-spin-button,
    input[type=number]::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    input[type=number] {
        -moz-appearance: textfield;
    }

    /* Perbaikan tampilan umum */
    body {
        background: linear-gradient(135deg, #f8fafc, #ecfeff, #dbeafe);
        font-family: 'Inter', sans-serif;
        margin: 0;
        padding: 20px;
    }

    .glass-card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.25);
        box-shadow: 0 15px 40px rgba(0, 0, 0, 0.08);
        transition: box-shadow 0.2s;
    }
    .glass-card:hover {
        box-shadow: 0 20px 50px rgba(0, 0, 0, 0.12);
    }

    .table-row:hover {
        background: #ecfeff;
        transition: 0.3s;
    }

    /* Efek fokus lebih halus */
    input:focus,
    select:focus {
        outline: none;
        border-color: #6366f1;
        box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15);
    }

    /* Tombol dengan transisi lebih smooth */
    .btn-remove {
        transition: all 0.2s;
    }

    /* Badge stok dengan animasi */
    .stok-value {
        transition: all 0.2s;
    }

    /* Responsif tambahan */
    @media (max-width: 640px) {
        .max-w-7xl {
            padding-left: 12px;
            padding-right: 12px;
        }
        .glass-card .p-8 {
            padding: 16px;
        }
        table td,
        table th {
            padding: 8px 10px;
        }
    }
</style>

<div class="max-w-7xl mx-auto px-4 sm:px-6 py-8 antialiased font-sans min-h-screen">

    <!-- Header -->
    <div class="flex items-center gap-4 mb-8 pb-6 border-b border-slate-200">
        <div class="p-3.5 bg-gradient-to-br from-vibrant-teal to-vibrant-blue rounded-2xl text-white shadow-lg shadow-vibrant-teal/20">
            <i data-lucide="plus-circle" class="w-8 h-8"></i>
        </div>
        <div>
            <h1 class="text-3xl font-black tracking-tighter bg-gradient-to-r from-vibrant-teal to-vibrant-blue bg-clip-text text-transparent">Buat Sales Order</h1>
            <p class="mt-1 text-base text-slate-600 font-medium">Pilih pelanggan dan tentukan item produk dengan lebih cepat dan berwarna.</p>
        </div>
    </div>

    <form method="post" action="<?php echo e(url('orders/store')); ?>" id="orderForm" class="space-y-8">
        <?php echo csrf_input(); ?>

        <!-- Detail Transaksi -->
        <div class="glass-card rounded-3xl overflow-hidden">
            <div class="p-6 bg-vibrant-indigo/5 border-b border-vibrant-indigo/10 flex items-center gap-3">
                <i data-lucide="info" class="w-5 h-5 text-vibrant-indigo"></i>
                <h3 class="text-sm font-bold text-vibrant-indigo uppercase tracking-wider">
                    Detail Transaksi Utama
                </h3>
            </div>
            <div class="p-6 sm:p-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Tanggal Order</label>
                    <input type="date" name="tanggal_order" value="<?php echo e(date('Y-m-d')); ?>" required
                        class="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 focus:border-vibrant-indigo focus:ring-4 focus:ring-vibrant-indigo/10 transition shadow-sm">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Pelanggan</label>
                    <select name="id_pelanggan" required
                        class="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 focus:border-vibrant-indigo focus:ring-4 focus:ring-vibrant-indigo/10 transition shadow-sm appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2020%2020%20fill%3D%22currentColor%22%3E%3Cpath%20fill-rule%3D%22evenodd%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%20clip-rule%3D%22evenodd%22%20%2F%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_0.75rem_center] bg-no-repeat pr-10">
                        <option value="">-- Pilih Pelanggan --</option>
                        <?php foreach ($pelanggan as $p): ?>
                            <option value="<?php echo e($p->id_pelanggan); ?>"><?php echo e($p->nama_pelanggan); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if ($current_user['role'] === 'Admin'): ?>
                <div>
                    <label class="block text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">Sales PJ</label>
                    <select name="id_sales" required
                        class="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 focus:border-vibrant-indigo focus:ring-4 focus:ring-vibrant-indigo/10 transition shadow-sm appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2020%2020%20fill%3D%22currentColor%22%3E%3Cpath%20fill-rule%3D%22evenodd%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%20clip-rule%3D%22evenodd%22%20%2F%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_0.75rem_center] bg-no-repeat pr-10">
                        <option value="">-- Pilih Sales --</option>
                        <?php foreach ($salesList as $s): ?>
                            <option value="<?php echo e($s->id_sales); ?>"><?php echo e($s->nama); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Item Produk -->
        <div class="glass-card rounded-3xl overflow-hidden">
            <div class="p-6 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4">
                <div class="flex items-center gap-3">
                    <i data-lucide="package" class="w-6 h-6 text-vibrant-teal"></i>
                    <h2 class="text-xl font-bold text-slate-950">Daftar Item Produk</h2>
                </div>
                <button type="button" id="addItem" class="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-vibrant-teal rounded-full hover:bg-[#0aa6c2] transition focus:outline-none focus:ring-4 focus:ring-vibrant-teal/20 shadow-md shadow-vibrant-teal/10">
                    <i data-lucide="plus" class="w-4 h-4"></i> Tambah Item
                </button>
            </div>

            <div class="overflow-x-auto">
                <table id="orderItems" class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50 border-b border-slate-100 text-[11px] font-bold tracking-wider text-slate-500 uppercase">
                            <th class="py-4 px-4 sm:px-6 w-[38%]">Produk</th>
                            <th class="py-4 px-3 sm:px-4 text-right">Harga Satuan</th>
                            <th class="py-4 px-3 sm:px-4 text-center">Stok</th>
                            <th class="py-4 px-3 sm:px-4 text-center w-[12%]">Qty</th>
                            <th class="py-4 px-4 sm:px-6 text-right">Subtotal</th>
                            <th class="py-4 px-3 sm:px-4 text-center w-[6%]"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 text-sm text-slate-700">
                        <tr class="group bg-blue-50/50 hover:bg-blue-50/70 transition rounded-lg">
                            <td class="py-4 px-4 sm:px-6">
                                <select name="id_produk[]" class="product-select w-full rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-sm font-medium focus:border-vibrant-teal focus:ring-4 focus:ring-vibrant-teal/10 transition appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2020%2020%20fill%3D%22currentColor%22%3E%3Cpath%20fill-rule%3D%22evenodd%22%20d%3D%22M5.293%207.293a1%201%200%20011.414%200L10%2010.586l3.293-3.293a1%201%200%20111.414%201.414l-4%204a1%201%200%2001-1.414%200l-4-4a1%201%200%20010-1.414z%22%20clip-rule%3D%22evenodd%22%20%2F%3E%3C%2Fsvg%3E')] bg-[length:1.1rem_1.1rem] bg-[right_0.6rem_center] bg-no-repeat pr-8" required>
                                    <option value="" data-harga="0" data-stok="0">-- Pilih Produk --</option>
                                    <?php foreach ($produk as $p): ?>
                                        <option value="<?php echo e($p->id_produk); ?>" data-harga="<?php echo e($p->harga); ?>" data-stok="<?php echo e($p->stok); ?>">
                                            <?php echo e($p->kode_produk . ' - ' . $p->nama_produk); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td class="py-4 px-3 sm:px-4 text-right font-semibold text-slate-800 harga">Rp 0</td>
                            <td class="py-4 px-3 sm:px-4 text-center font-bold text-slate-600 stok">
                                <span class="stok-value p-2 px-3 rounded-full text-xs bg-slate-100 text-slate-600">0</span>
                            </td>
                            <td class="py-4 px-3 sm:px-4">
                                <input type="number" name="jumlah[]" class="qty w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-center text-sm font-semibold text-slate-900 focus:border-vibrant-teal focus:ring-4 focus:ring-vibrant-teal/10 transition shadow-inner" min="1" value="1" required>
                            </td>
                            <td class="py-4 px-4 sm:px-6 text-right font-black text-vibrant-indigo subtotal">Rp 0</td>
                            <td class="py-4 px-3 sm:px-4 text-center">
                                <button type="button" class="btn-remove inline-flex items-center justify-center p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-100 transition opacity-0 group-hover:opacity-100 focus:opacity-100">
                                    <i data-lucide="x" class="w-4 h-4"></i>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Total Akhir -->
            <div class="p-6 sm:p-8 bg-slate-50 border-t border-slate-100 flex flex-col md:flex-row md:items-center md:justify-end gap-6">
                <div class="w-full md:w-auto text-center md:text-left text-sm font-semibold text-slate-500 uppercase tracking-widest">
                    TOTAL AKHIR PESANAN
                </div>
                <div class="w-full md:w-96 bg-white border border-slate-200 rounded-3xl px-8 py-5 flex items-center justify-center shadow-lg shadow-vibrant-blue/5">
                    <span id="grandTotal" class="text-4xl font-extrabold tracking-tighter text-vibrant-blue">Rp 0</span>
                </div>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="flex flex-col-reverse sm:flex-row items-center justify-end gap-4 pt-4 pb-12">
            <a href="<?php echo e(url('orders')); ?>"
               class="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 border border-slate-300 rounded-full text-sm font-medium text-slate-700 bg-white hover:bg-slate-50 focus:outline-none focus:ring-4 focus:ring-slate-300/20 transition shadow-sm">
                <i data-lucide="arrow-left" class="w-4 h-4"></i> Kembali
            </a>
            <button type="submit"
                    class="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-3.5 bg-gradient-to-r from-vibrant-teal to-vibrant-blue border border-transparent rounded-full text-sm font-bold text-white hover:shadow-lg hover:shadow-vibrant-blue/20 focus:outline-none focus:ring-4 focus:ring-vibrant-blue/30 transition shadow-md shadow-vibrant-blue/10">
                <i data-lucide="save" class="w-5 h-5"></i> Simpan Sales Order
            </button>
        </div>
    </form>
</div>

<script>
    lucide.createIcons();

    // Jalankan inisialisasi pada load pertama kali
    document.addEventListener('DOMContentLoaded', () => {
        const defaultRow = document.querySelector('#orderItems tbody tr');
        setupRowEvents(defaultRow);
    });

    // Event handler utama untuk baris
    function setupRowEvents(row) {
        const select = row.querySelector('.product-select');
        const qtyInput = row.querySelector('.qty');
        const removeBtn = row.querySelector('.btn-remove');

        select.addEventListener('change', () => calculateSubtotal(row));
        qtyInput.addEventListener('input', () => calculateSubtotal(row));
        removeBtn.addEventListener('click', () => {
            const tbody = document.querySelector('#orderItems tbody');
            if (tbody.rows.length > 1) {
                row.remove();
                calculateGrandTotal();
            } else {
                alert('Minimal harus ada 1 item produk!');
            }
        });
    }

    // Hitung Subtotal & Update Stok
    function calculateSubtotal(row) {
        const select = row.querySelector('.product-select');
        const option = select.options[select.selectedIndex];
        const qtyInput = row.querySelector('.qty');
        const hargaTd = row.querySelector('.harga');
        const stokSpn = row.querySelector('.stok .stok-value');
        const subtotalTd = row.querySelector('.subtotal');

        const harga = parseFloat(option.dataset.harga) || 0;
        const stokMax = parseInt(option.dataset.stok) || 0;
        let qty = parseInt(qtyInput.value) || 0;

        // Batasi Qty sesuai Stok
        if (qty > stokMax && stokMax > 0) {
            alert(`Stok produk tidak mencukupi! Maksimal stok tersedia adalah ${stokMax}.`);
            qty = stokMax;
            qtyInput.value = stokMax;
        }

        // Hitung Subtotal
        const subtotal = harga * qty;

        // Update Visuals
        hargaTd.textContent = formatRupiah(harga);
        subtotalTd.textContent = formatRupiah(subtotal);
        stokSpn.textContent = stokMax;

        // Logika Warna Stok
        updateStokVisual(stokSpn, stokMax);

        calculateGrandTotal();
    }

    // Update Warna Badge Stok
    function updateStokVisual(span, stokValue) {
        if (stokValue > 10) {
            span.className = "stok-value p-2 px-3 rounded-full text-xs font-bold bg-green-50 text-green-700";
        } else if (stokValue > 0 && stokValue <= 10) {
            span.className = "stok-value p-2 px-3 rounded-full text-xs font-bold bg-amber-50 text-amber-700";
        } else if (stokValue === 0) {
            span.className = "stok-value p-2 px-3 rounded-full text-xs font-bold bg-rose-50 text-rose-700";
        }
    }

    // Hitung Grand Total Akhir
    function calculateGrandTotal() {
        let total = 0;
        document.querySelectorAll('.subtotal').forEach(el => {
            const val = parseInt(el.textContent.replace(/[^0-9]/g, '')) || 0;
            total += val;
        });
        document.getElementById('grandTotal').textContent = formatRupiah(total);
    }

    // Format Rupiah
    function formatRupiah(angka) {
        return 'Rp ' + angka.toLocaleString('id-ID');
    }

    // Logika Tambah Baris Baru
    document.getElementById('addItem').addEventListener('click', () => {
        const tbody = document.querySelector('#orderItems tbody');
        const templateRow = tbody.rows[0].cloneNode(true);

        // Reset Data di Baris Baru
        templateRow.querySelector('.product-select').selectedIndex = 0;
        templateRow.querySelector('.qty').value = 1;
        templateRow.querySelector('.harga').textContent = 'Rp 0';
        templateRow.querySelector('.subtotal').textContent = 'Rp 0';
        templateRow.querySelector('.stok .stok-value').textContent = '0';
        templateRow.querySelector('.stok .stok-value').className = "stok-value p-2 px-3 rounded-full text-xs font-bold bg-slate-100 text-slate-600";

        // Atur agar baris baru tidak berwarna biru
        templateRow.className = "group hover:bg-slate-50 transition rounded-lg";

        tbody.appendChild(templateRow);
        setupRowEvents(templateRow);
        lucide.createIcons(); // render ulang ikon trash
    });
</script>