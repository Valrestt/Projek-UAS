<style>
    /* Global */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, #f8fafc, #ecfeff, #dbeafe);
        min-height: 100vh;
        padding: 30px 35px;
        margin: 0;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
    }

    /* ----- PAGE HEADER ----- */
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 30px;
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(12px);
        padding: 20px 28px;
        border-radius: 32px;
        box-shadow: 0 15px 35px -10px rgba(0,0,0,0.08);
        border: 1px solid rgba(255,255,255,0.6);
    }

    .page-header h1 {
        font-size: 2rem;
        font-weight: 800;
        background: linear-gradient(135deg, #06b6d4, #3b82f6);
        -webkit-background-clip: text;
        background-clip: text;
        color: transparent;
        margin-bottom: 4px;
        letter-spacing: -0.5px;
    }

    .page-header p {
        color: #475569;
        font-weight: 500;
    }

    .btn-secondary {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 24px;
        background: white;
        border: 1px solid #cbd5e1;
        border-radius: 40px;
        font-weight: 600;
        color: #1e293b;
        text-decoration: none;
        transition: all 0.2s;
        box-shadow: 0 4px 10px rgba(0,0,0,0.02);
    }

    .btn-secondary:hover {
        background: #f1f5f9;
        border-color: #94a3b8;
        transform: translateY(-2px);
        box-shadow: 0 8px 16px rgba(0,0,0,0.06);
    }

    /* ----- CARDS ----- */
    .cards {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }

    .card-stat {
        background: rgba(255, 255, 255, 0.8);
        backdrop-filter: blur(8px);
        padding: 20px 24px;
        border-radius: 24px;
        border: 1px solid rgba(255,255,255,0.5);
        box-shadow: 0 8px 20px -8px rgba(0,0,0,0.06);
        transition: all 0.2s;
    }

    .card-stat:hover {
        transform: translateY(-3px);
        box-shadow: 0 16px 30px -10px rgba(0,0,0,0.1);
    }

    .card-stat span {
        display: block;
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-weight: 600;
        color: #64748b;
        margin-bottom: 6px;
    }

    .card-stat strong {
        font-size: 1.2rem;
        font-weight: 700;
        color: #0f172a;
    }

    /* ----- CARD UTAMA ----- */
    .card {
        background: rgba(255, 255, 255, 0.85);
        backdrop-filter: blur(12px);
        border-radius: 28px;
        padding: 24px 30px;
        margin-bottom: 28px;
        border: 1px solid rgba(255,255,255,0.5);
        box-shadow: 0 12px 30px -12px rgba(0,0,0,0.08);
        transition: box-shadow 0.2s;
    }

    .card:hover {
        box-shadow: 0 18px 40px -12px rgba(0,0,0,0.12);
    }

    .section-title {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 16px;
        padding-bottom: 10px;
        border-bottom: 2px solid #e2e8f0;
    }

    .section-title h2 {
        font-size: 1.2rem;
        font-weight: 700;
        color: #0f172a;
        letter-spacing: -0.3px;
    }

    /* Badge Status */
    .badge {
        display: inline-block;
        padding: 6px 18px;
        border-radius: 40px;
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: capitalize;
        letter-spacing: 0.3px;
    }

    .badge.draft {
        background: #ffedd5;
        color: #b45309;
        border-left: 4px solid #f97316;
    }
    .badge.dikirim {
        background: #dbeafe;
        color: #1e40af;
        border-left: 4px solid #3b82f6;
    }
    .badge.selesai {
        background: #d1fae5;
        color: #065f46;
        border-left: 4px solid #10b981;
    }
    .badge.dibatalkan {
        background: #fee2e2;
        color: #b91c1c;
        border-left: 4px solid #ef4444;
    }

    /* Grid Info */
    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 16px;
    }

    .info-grid div {
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .info-grid span {
        font-size: 0.7rem;
        text-transform: uppercase;
        letter-spacing: 0.4px;
        font-weight: 600;
        color: #64748b;
    }

    .info-grid strong {
        font-size: 1rem;
        font-weight: 600;
        color: #0f172a;
        word-break: break-word;
    }

    /* ----- TABEL ----- */
    .table-wrap {
        overflow-x: auto;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.9rem;
    }

    thead th {
        background: #f1f5f9;
        padding: 14px 16px;
        text-align: left;
        font-weight: 600;
        color: #334155;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 2px solid #e2e8f0;
    }

    tbody td {
        padding: 14px 16px;
        border-bottom: 1px solid #f1f5f9;
        color: #1e293b;
    }

    tbody tr:last-child td {
        border-bottom: none;
    }

    tbody tr:hover {
        background: #f8fafc;
    }

    /* ----- FORM UBAH STATUS ----- */
    .inline-form {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 12px;
        margin-top: 8px;
    }

    .inline-form select {
        padding: 10px 20px;
        border: 1px solid #cbd5e1;
        border-radius: 40px;
        background: white;
        font-weight: 500;
        font-size: 0.9rem;
        color: #0f172a;
        min-width: 160px;
        transition: 0.2s;
    }

    .inline-form select:focus {
        border-color: #3b82f6;
        outline: none;
        box-shadow: 0 0 0 4px rgba(59,130,246,0.15);
    }

    .btn-primary {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 28px;
        background: linear-gradient(135deg, #06b6d4, #3b82f6);
        color: white;
        border: none;
        border-radius: 40px;
        font-weight: 700;
        font-size: 0.9rem;
        cursor: pointer;
        transition: all 0.2s;
        box-shadow: 0 8px 16px -6px rgba(59,130,246,0.3);
    }

    .btn-primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 14px 24px -8px rgba(59,130,246,0.4);
    }

    /* ----- RESPONSIVE ----- */
    @media (max-width: 640px) {
        body {
            padding: 16px;
        }

        .page-header {
            flex-direction: column;
            align-items: stretch;
            gap: 16px;
            text-align: center;
            padding: 16px 18px;
        }

        .page-header h1 {
            font-size: 1.6rem;
        }

        .cards {
            grid-template-columns: 1fr;
        }

        .card {
            padding: 18px 16px;
        }

        .info-grid {
            grid-template-columns: 1fr 1fr;
        }

        .inline-form {
            flex-direction: column;
            align-items: stretch;
        }

        .inline-form select,
        .btn-primary {
            width: 100%;
            justify-content: center;
        }
    }
</style>

<div class="container">
    <!-- Header -->
    <div class="page-header">
        <div>
            <h1>Detail Order</h1>
            <p><?php echo e($order->no_order); ?></p>
        </div>
        <a class="btn-secondary" href="<?php echo e(url('orders')); ?>">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
    </div>

    <!-- Cards Ringkasan -->
    <div class="cards">
        <div class="card-stat">
            <span>Pelanggan</span>
            <strong><?php echo e($order->nama_pelanggan); ?></strong>
        </div>
        <div class="card-stat">
            <span>Sales</span>
            <strong><?php echo e($order->nama_sales); ?></strong>
        </div>
        <div class="card-stat">
            <span>Total</span>
            <strong><?php echo e(rupiah($order->total_harga)); ?></strong>
        </div>
    </div>

    <!-- Informasi Order -->
    <div class="card">
        <div class="section-title">
            <h2>Informasi Order</h2>
            <span class="badge <?php echo e($order->status); ?>"><?php echo e($order->status); ?></span>
        </div>
        <div class="info-grid">
            <div>
                <span>No Order</span>
                <strong><?php echo e($order->no_order); ?></strong>
            </div>
            <div>
                <span>Tanggal</span>
                <strong><?php echo e($order->tanggal_order); ?></strong>
            </div>
            <div>
                <span>No. Telp</span>
                <strong><?php echo e($order->no_telp); ?></strong>
            </div>
            <div>
                <span>Alamat</span>
                <strong><?php echo e($order->alamat); ?></strong>
            </div>
        </div>
    </div>

    <!-- Detail Produk -->
    <div class="card">
        <h2 style="font-size:1.2rem; font-weight:700; color:#0f172a; margin-bottom:16px;">Detail Produk</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Kode</th>
                        <th>Produk</th>
                        <th>Harga</th>
                        <th>Qty</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($details as $d): ?>
                        <tr>
                            <td><?php echo e($d->kode_produk); ?></td>
                            <td><?php echo e($d->nama_produk); ?></td>
                            <td><?php echo e(rupiah($d->harga_satuan)); ?></td>
                            <td><?php echo e($d->jumlah); ?></td>
                            <td><?php echo e(rupiah($d->subtotal)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Ubah Status -->
    <div class="card">
        <h2 style="font-size:1.2rem; font-weight:700; color:#0f172a; margin-bottom:12px;">Ubah Status Order</h2>
        <form method="post" action="<?php echo e(url('orders/status')); ?>" class="inline-form">
            <?php echo csrf_input(); ?>
            <input type="hidden" name="id" value="<?php echo e($order->id_order); ?>">
            <select name="status">
                <option value="draft" <?php echo selected($order->status, 'draft'); ?>>draft</option>
                <option value="dikirim" <?php echo selected($order->status, 'dikirim'); ?>>dikirim</option>
                <option value="selesai" <?php echo selected($order->status, 'selesai'); ?>>selesai</option>
                <option value="dibatalkan" <?php echo selected($order->status, 'dibatalkan'); ?>>dibatalkan</option>
            </select>
            <button class="btn-primary" type="submit">
                <i class="fas fa-sync-alt"></i> Update Status
            </button>
        </form>
    </div>
</div>