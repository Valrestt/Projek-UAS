<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Laporan Penjualan | <?php echo e($app_name ?? 'Sales Order'); ?></title>
    <!-- Google Fonts + Font Awesome -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f4ff, #e9f0fa, #fef2f8, #e6f7f0);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            min-height: 100vh;
            padding: 30px 35px;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 0%; }
            25% { background-position: 100% 0%; }
            50% { background-position: 100% 100%; }
            75% { background-position: 0% 100%; }
            100% { background-position: 0% 0%; }
        }

        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJmIj48ZmVUdXJidWxlbmNlIHR5cGU9ImZyYWN0YWxOb2lzZSIgYmFzZUZyZXF1ZW5jeT0iLjciIG51bU9jdGF2ZXM9IjMiLz48L2ZpbHRlcj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWx0ZXI9InVybCgjZikiIG9wYWNpdHk9IjAuMDYiLz48L3N2Zz4=');
            background-repeat: repeat;
            pointer-events: none;
            z-index: 0;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
        }

        /* Header halaman */
        .page-header {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            padding: 20px 28px;
            border-radius: 32px;
            margin-bottom: 32px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.6);
        }
        .page-header h1 {
            font-size: 1.9rem;
            font-weight: 800;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 6px;
        }
        .page-header p {
            color: #4a627a;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .page-header p i {
            color: #3b82f6;
        }

        /* Form filter modern */
        .filter-form {
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            border-radius: 32px;
            padding: 24px 28px;
            margin-bottom: 32px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.6);
            display: flex;
            flex-wrap: wrap;
            align-items: flex-end;
            gap: 20px;
        }
        .filter-form > div {
            flex: 1;
            min-width: 180px;
        }
        .filter-form label {
            display: block;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
            color: #4a627a;
            margin-bottom: 6px;
            letter-spacing: 0.5px;
        }
        .filter-form label i {
            margin-right: 6px;
            color: #3b82f6;
        }
        .filter-form input {
            width: 100%;
            padding: 12px 16px;
            background: rgba(255,255,255,0.9);
            border: 1px solid #e2e8f0;
            border-radius: 28px;
            font-size: 0.9rem;
            transition: 0.2s;
        }
        .filter-form input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59,130,246,0.2);
        }
        .filter-actions {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }
        .btn {
            padding: 10px 20px;
            border-radius: 40px;
            font-weight: 600;
            font-size: 0.85rem;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: 0.2s;
            border: none;
            cursor: pointer;
        }
        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #1e3a8a);
            color: white;
            box-shadow: 0 8px 16px -6px rgba(59,130,246,0.4);
        }
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px -8px rgba(59,130,246,0.6);
        }
        .btn-secondary {
            background: rgba(100,116,139,0.15);
            color: #334155;
            border: 1px solid rgba(100,116,139,0.2);
        }
        .btn-secondary:hover {
            background: #334155;
            color: white;
            transform: translateY(-2px);
        }
        .btn-success {
            background: rgba(16,185,129,0.15);
            color: #065f46;
            border: 1px solid rgba(16,185,129,0.2);
        }
        .btn-success:hover {
            background: #10b981;
            color: white;
            transform: translateY(-2px);
        }

        /* Stat Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 24px;
            margin-bottom: 36px;
        }
        .stat-card {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(12px);
            border-radius: 28px;
            padding: 20px 24px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.6);
            transition: 0.2s;
        }
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 28px 40px -12px rgba(0,0,0,0.15);
        }
        .stat-card span {
            font-size: 0.85rem;
            text-transform: uppercase;
            font-weight: 600;
            color: #5b7f95;
            display: block;
            margin-bottom: 8px;
        }
        .stat-card strong {
            font-size: 2rem;
            font-weight: 800;
            color: #0a2942;
        }

        /* Tabel card */
        .table-wrap {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(12px);
            border-radius: 32px;
            padding: 20px 0 20px 0;
            margin-bottom: 32px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.6);
            overflow-x: auto;
        }
        .table-wrap h2 {
            padding: 0 20px 16px 20px;
            font-size: 1.3rem;
            font-weight: 700;
            color: #1e3c72;
            display: flex;
            align-items: center;
            gap: 10px;
            border-bottom: 2px solid rgba(59,130,246,0.2);
        }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            font-size: 0.9rem;
        }
        th {
            padding: 16px 20px;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            color: white;
            font-weight: 600;
            text-align: left;
        }
        th:first-child { border-radius: 20px 0 0 20px; }
        th:last-child { border-radius: 0 20px 20px 0; }
        tbody tr {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            transition: 0.2s;
            box-shadow: 0 8px 16px -8px rgba(0,0,0,0.05);
        }
        tbody tr:hover {
            transform: translateY(-2px);
            background: white;
            box-shadow: 0 16px 24px -10px rgba(0,0,0,0.12);
        }
        td {
            padding: 14px 20px;
            color: #1e2f3e;
        }
        .empty {
            text-align: center;
            padding: 40px;
            color: #5b7f95;
            font-style: italic;
        }

        @media (max-width: 768px) {
            body { padding: 20px; }
            .filter-form { flex-direction: column; align-items: stretch; }
            .filter-actions { justify-content: flex-start; }
            th, td { padding: 10px 12px; }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- Header -->
    <div class="page-header">
        <div>
            <h1><i class="fas fa-chart-line"></i> Laporan Penjualan</h1>
            <p><i class="fas fa-file-alt"></i> Laporan penjualan per sales, per produk, dan per periode.</p>
        </div>
    </div>

    <!-- Form Filter -->
    <form class="filter-form" method="get" action="<?php echo e(base_url('index.php')); ?>">
        <input type="hidden" name="r" value="laporan">
        <div>
            <label><i class="fas fa-calendar-alt"></i> Tanggal Awal</label>
            <input type="date" name="tanggal_awal" value="<?php echo e($tanggal_awal); ?>">
        </div>
        <div>
            <label><i class="fas fa-calendar-check"></i> Tanggal Akhir</label>
            <input type="date" name="tanggal_akhir" value="<?php echo e($tanggal_akhir); ?>">
        </div>
        <div class="filter-actions">
            <button class="btn btn-primary" type="submit"><i class="fas fa-filter"></i> Filter</button>
            <a class="btn btn-secondary" href="<?php echo e(url('laporan')); ?>"><i class="fas fa-undo-alt"></i> Reset</a>
            <a class="btn btn-success" href="<?php echo e(url('laporan/pdf&tanggal_awal=' . urlencode($tanggal_awal) . '&tanggal_akhir=' . urlencode($tanggal_akhir))); ?>"><i class="fas fa-file-pdf"></i> Export PDF</a>
            <button class="btn btn-secondary" type="button" onclick="window.print()"><i class="fas fa-print"></i> Cetak</button>
        </div>
    </form>

    <!-- Stat Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <span><i class="fas fa-check-circle"></i> Total Order Selesai</span>
            <strong><?php echo e($cards->total_order); ?></strong>
        </div>
        <div class="stat-card">
            <span><i class="fas fa-chart-line"></i> Total Penjualan</span>
            <strong><?php echo e(rupiah($cards->total_penjualan)); ?></strong>
        </div>
    </div>

    <!-- Penjualan per Sales -->
    <div class="table-wrap">
        <h2><i class="fas fa-user-tie"></i> Penjualan per Sales</h2>
        <table>
            <thead>
                <tr><th>Nama Sales</th><th>Jumlah Order</th><th>Total Penjualan</th></tr>
            </thead>
            <tbody>
                <?php foreach ($perSales as $row): ?>
                <tr>
                    <td><strong><?php echo e($row->nama_sales); ?></strong></td>
                    <td><?php echo e($row->jumlah_order); ?></td>
                    <td><?php echo e(rupiah($row->total_penjualan)); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($perSales)): ?>
                <tr><td colspan="3" class="empty"><i class="fas fa-database"></i> Tidak ada data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Penjualan per Produk -->
    <div class="table-wrap">
        <h2><i class="fas fa-boxes"></i> Penjualan per Produk</h2>
        <table>
            <thead>
                <tr><th>Kode</th><th>Produk</th><th>Qty Terjual</th><th>Total Penjualan</th></tr>
            </thead>
            <tbody>
                <?php foreach ($perProduk as $row): ?>
                <tr>
                    <td><?php echo e($row->kode_produk); ?></td>
                    <td><?php echo e($row->nama_produk); ?></td>
                    <td><?php echo e($row->jumlah_terjual); ?></td>
                    <td><?php echo e(rupiah($row->total_penjualan)); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($perProduk)): ?>
                <tr><td colspan="4" class="empty"><i class="fas fa-database"></i> Tidak ada data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Penjualan per Periode -->
    <div class="table-wrap">
        <h2><i class="fas fa-chart-simple"></i> Penjualan per Periode</h2>
        <table>
            <thead>
                <tr><th>Tanggal</th><th>Jumlah Order</th><th>Total Penjualan</th></tr>
            </thead>
            <tbody>
                <?php foreach ($perPeriode as $row): ?>
                <tr>
                    <td><?php echo e($row->tanggal_order); ?></td>
                    <td><?php echo e($row->jumlah_order); ?></td>
                    <td><?php echo e(rupiah($row->total_penjualan)); ?></td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($perPeriode)): ?>
                <tr><td colspan="3" class="empty"><i class="fas fa-database"></i> Tidak ada data.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>