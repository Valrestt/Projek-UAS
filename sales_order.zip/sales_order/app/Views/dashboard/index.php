<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Dashboard Penjualan | PT Maju Jaya</title>
    <!-- Google Fonts + Font Awesome 6 + Chart.js -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ========== BACKGROUND BERGERAK ========== */
        body {
            font-family: 'Inter', sans-serif;
            padding: 24px 32px;
            color: #1a2c3e;
            min-height: 100vh;
            background: linear-gradient(135deg, #f0f4ff, #e9f0fa, #fef2f8, #e6f7f0);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 0%; }
            25% { background-position: 100% 0%; }
            50% { background-position: 100% 100%; }
            75% { background-position: 0% 100%; }
            100% { background-position: 0% 0%; }
        }

        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJmIj48ZmVUdXJidWxlbmNlIHR5cGU9ImZyYWN0YWxOb2lzZSIgYmFzZUZyZXF1ZW5jeT0iLjciIG51bU9jdGF2ZXM9IjMiLz48L2ZpbHRlcj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWx0ZXI9InVybCgjZikiIG9wYWNpdHk9IjAuMDYiLz48L3N2Zz4=');
            background-repeat: repeat;
            pointer-events: none;
            z-index: 0;
        }

        .container {
            max-width: 1440px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
        }

        /* ========== HEADER ========== */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            flex-wrap: wrap;
            gap: 20px;
        }

        .title-section h1 {
            font-size: 2.2rem;
            font-weight: 800;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c, #3b82f6);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: -0.02em;
            display: inline-block;
            position: relative;
            animation: fadeInUp 0.5s ease;
        }
        .title-section h1::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #3b82f6, #8b5cf6, #ec489a);
            border-radius: 4px;
            transition: width 0.3s ease;
        }
        .title-section:hover h1::after { width: 100px; }
        .title-section p {
            color: #2c3e50;
            font-size: 0.95rem;
            margin-top: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
        }
        .hero-badge {
            background: rgba(59, 130, 246, 0.15);
            backdrop-filter: blur(4px);
            padding: 4px 12px;
            border-radius: 40px;
            font-size: 0.7rem;
            font-weight: 600;
            color: #1e4a76;
            border: 1px solid rgba(59, 130, 246, 0.3);
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .hero-badge i { color: #3b82f6; }

        /* Admin profile + tombol logout dengan bayangan tebal */
        .admin-area {
            display: flex;
            align-items: center;
            gap: 16px;
        }
        .admin-profile {
            display: flex;
            align-items: center;
            gap: 16px;
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(8px);
            padding: 8px 24px;
            border-radius: 80px;
            box-shadow: 0 20px 35px -8px rgba(0, 0, 0, 0.2), 0 0 0 1px rgba(255,255,255,0.5);
            transition: all 0.2s;
        }
        .admin-profile:hover {
            background: white;
            transform: translateY(-3px);
            box-shadow: 0 30px 45px -10px rgba(0, 0, 0, 0.25);
        }
        .admin-profile i { color: #4f46e5; }
        .badge-role {
            background: linear-gradient(135deg, #eef2ff, #e0e7ff);
            color: #1e4a76;
            border-radius: 50px;
            padding: 4px 12px;
            font-size: 0.7rem;
            font-weight: 700;
            margin-left: 6px;
        }
        .logout-btn {
            background: rgba(239, 68, 68, 0.12);
            backdrop-filter: blur(8px);
            padding: 8px 20px;
            border-radius: 80px;
            text-decoration: none;
            color: #ef4444;
            font-weight: 600;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 8px;
            border: 1px solid rgba(239, 68, 68, 0.2);
            transition: 0.2s;
            box-shadow: 0 12px 25px -5px rgba(0,0,0,0.15);
        }
        .logout-btn:hover {
            background: #ef4444;
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 20px 35px -8px rgba(239,68,68,0.4);
        }
        .logout-btn i { color: #ef4444; }
        .logout-btn:hover i { color: white; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Stat Cards dengan bayangan sangat tebal */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }
        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(2px);
            padding: 20px 24px;
            border-radius: 28px;
            transition: transform 0.2s, box-shadow 0.2s;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: 0 25px 40px -12px rgba(0, 0, 0, 0.2);
        }
        .stat-card:hover { 
            transform: translateY(-6px); 
            background: white; 
            box-shadow: 0 35px 55px -15px rgba(0, 0, 0, 0.3);
        }
        .stat-icon { font-size: 2.2rem; margin-bottom: 16px; }
        .stat-card:nth-child(1) .stat-icon { color: #3b82f6; }
        .stat-card:nth-child(2) .stat-icon { color: #10b981; }
        .stat-card:nth-child(3) .stat-icon { color: #8b5cf6; }
        .stat-value { font-size: 2rem; font-weight: 800; color: #0a2942; }
        .stat-label { font-size: 0.85rem; text-transform: uppercase; font-weight: 600; color: #5b7f95; margin-top: 8px; }
        .stat-sub { font-size: 0.75rem; color: #8aaec0; margin-top: 4px; }

        /* Section title - beri warna ikon */
        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin: 28px 0 18px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .section-title .fa-bolt { color: #f59e0b; }
        .section-title .fa-clock { color: #3b82f6; }
        .section-title i:not(.fa-bolt):not(.fa-clock) { color: #8b5cf6; }

        /* Aksi Cepat dengan bayangan sangat tebal */
        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 32px;
        }
        .action-btn {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(2px);
            padding: 18px 12px;
            border-radius: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            font-weight: 600;
            text-decoration: none;
            color: #1e4663;
            transition: 0.2s;
            border: 1px solid rgba(255, 255, 255, 0.5);
            box-shadow: 0 20px 35px -10px rgba(0, 0, 0, 0.2);
        }
        .action-btn i { font-size: 1.3rem; }
        .action-btn:nth-child(1) i { color: #f59e0b; }
        .action-btn:nth-child(2) i { color: #3b82f6; }
        .action-btn:nth-child(3) i { color: #ec489a; }
        .action-btn:nth-child(4) i { color: #14b8a6; }
        .action-btn:hover { 
            background: #2c7da0; 
            color: white; 
            transform: translateY(-5px);
            box-shadow: 0 30px 45px -12px rgba(0, 0, 0, 0.3);
        }
        .action-btn:hover i { color: white !important; }

        /* Two columns dengan bayangan sangat tebal */
        .two-columns {
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            gap: 24px;
            margin-bottom: 36px;
        }
        .info-card, .chart-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(2px);
            border-radius: 28px;
            padding: 24px;
            border: 1px solid rgba(255, 255, 255, 0.6);
            box-shadow: 0 25px 40px -12px rgba(0, 0, 0, 0.2);
            transition: 0.2s;
        }
        .info-card:hover, .chart-card:hover {
            box-shadow: 0 35px 55px -15px rgba(0, 0, 0, 0.3);
        }
        .info-card h3 i { color: #8b5cf6; }
        .chart-card h3 i { color: #f97316; }
        .access-list { list-style: none; margin-top: 12px; }
        .access-list li { margin-bottom: 12px; display: flex; align-items: center; gap: 12px; }
        .access-list li i { width: 24px; }
        .access-list li:nth-child(1) i { color: #3b82f6; }
        .access-list li:nth-child(2) i { color: #10b981; }
        .access-list li:nth-child(3) i { color: #f59e0b; }
        .access-list li:nth-child(4) i { color: #ec489a; }
        .access-list li:nth-child(5) i { color: #8b5cf6; }

        /* Tabel dengan bayangan sangat tebal pada baris */
        .table-wrapper { overflow-x: auto; }
        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 14px;
        }
        th {
            padding: 16px 20px;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            color: white;
            box-shadow: 0 8px 18px rgba(0,0,0,0.15);
        }
        th:first-child { border-radius: 20px 0 0 20px; }
        th:last-child { border-radius: 0 20px 20px 0; }
        tbody tr {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 20px;
            transition: 0.2s;
            box-shadow: 0 15px 30px -8px rgba(0, 0, 0, 0.15);
        }
        tbody tr:hover { 
            transform: translateY(-4px); 
            background: white; 
            cursor: pointer;
            box-shadow: 0 25px 40px -10px rgba(0, 0, 0, 0.25);
        }
        td { padding: 14px 20px; }
        
        /* STATUS BADGE dengan warna jelas dan bayangan */
        .status-badge {
            display: inline-block;
            padding: 6px 14px;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: capitalize;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        /* Draft - Oranye */
        .status-badge.draft, 
        .status-badge.DRAFT {
            background: #ffedd5;
            color: #b45309;
            border-left: 3px solid #f97316;
        }
        /* Dikirim - Biru terang */
        .status-badge.dikirim, 
        .status-badge.DIKIRIM,
        .status-badge.sent,
        .status-badge.SENT {
            background: #dbeafe;
            color: #1e40af;
            border-left: 3px solid #3b82f6;
        }
        /* Selesai - Hijau */
        .status-badge.selesai, 
        .status-badge.SELESAI,
        .status-badge.completed,
        .status-badge.COMPLETED {
            background: #d1fae5;
            color: #065f46;
            border-left: 3px solid #10b981;
        }
        
        .btn-sm {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 6px 14px;
            border-radius: 40px;
            text-decoration: none;
            color: #1e4663;
            transition: 0.2s;
            box-shadow: 0 6px 12px rgba(0,0,0,0.05);
        }
        .btn-sm:hover { 
            background: #eef2ff; 
            box-shadow: 0 10px 20px rgba(0,0,0,0.12);
            transform: translateY(-1px);
        }

        /* Warna ikon di header tabel (receipt) */
        .table-wrapper span i { color: #14b8a6; }

        footer {
            margin-top: 40px;
            text-align: center;
            background: rgba(255,255,255,0.5);
            backdrop-filter: blur(4px);
            padding: 12px;
            border-radius: 40px;
            width: fit-content;
            margin: 40px auto 0;
            box-shadow: 0 12px 25px -8px rgba(0,0,0,0.15);
        }
        footer i { color: #8b5cf6; }

        canvas { max-height: 220px; width: 100%; }

        @media (max-width: 800px) {
            body { padding: 16px; }
            .two-columns { grid-template-columns: 1fr; }
            .admin-area { flex-wrap: wrap; justify-content: flex-end; }
        }
    </style>
</head>
<body>
<div class="container">
    <!-- HEADER -->
    <div class="header">
        <div class="title-section">
            <h1><i class="fas fa-chart-line" style="background: linear-gradient(135deg, #1e3c72, #2b4c7c); -webkit-background-clip: text; background-clip: text; color: transparent;"></i> Dashboard Penjualan</h1>
            <p>
                <span class="hero-badge"><i class="fas fa-store"></i> PT Maju Jaya</span>
                <span><i class="fas fa-chart-simple" style="color:#f59e0b;"></i> Ringkasan sistem sales order terintegrasi</span>
            </p>
        </div>

        <div class="admin-area">
            <div class="admin-profile">
                <i class="fas fa-user-astronaut"></i>
                <span><strong><?php echo e($current_user['role']); ?></strong> <span class="badge-role"><?php echo e($current_user['role'] === 'Admin' ? 'Super Access' : ($current_user['role'] === 'Sales' ? 'Sales Force' : 'Executive View')); ?></span></span>
                <small><?php echo e($current_user['nama']); ?></small>
            </div>
            <a href="<?php echo e(url('auth/logout')); ?>" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <!-- Stat Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
            <div class="stat-value"><?php echo e($cards->total_order); ?></div>
            <div class="stat-label">Total Order Selesai</div>
            <div class="stat-sub">✔️ Order berhasil diproses</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
            <div class="stat-value"><?php echo e(rupiah($cards->total_penjualan)); ?></div>
            <div class="stat-label">Total Penjualan</div>
            <div class="stat-sub">Total omzet penjualan</div>
        </div>
        <div class="stat-card">
            <div class="stat-icon"><i class="fas fa-user-cog"></i></div>
            <div class="stat-value"><?php echo e($current_user['role']); ?></div>
            <div class="stat-label">Role Aktif</div>
            <div class="stat-sub">Akses pengguna saat ini</div>
        </div>
    </div>

    <!-- Aksi Cepat -->
    <div class="section-title"><i class="fas fa-bolt"></i> Aksi Cepat</div>
    <div class="actions-grid">
        <?php if($current_user['role'] !== 'Manager'): ?>
            <a href="<?php echo e(url('orders/create')); ?>" class="action-btn"><i class="fas fa-plus-circle"></i> + Buat Order</a>
        <?php endif; ?>
        <?php if($current_user['role'] === 'Admin'): ?>
            <a href="<?php echo e(url('produk')); ?>" class="action-btn"><i class="fas fa-boxes"></i> Kelola Produk</a>
            <a href="<?php echo e(url('pelanggan')); ?>" class="action-btn"><i class="fas fa-users"></i> Kelola Pelanggan</a>
        <?php endif; ?>
        <?php if(in_array($current_user['role'], array('Admin','Manager'))): ?>
            <a href="<?php echo e(url('laporan')); ?>" class="action-btn"><i class="fas fa-file-alt"></i> Lihat Laporan</a>
        <?php endif; ?>
    </div>

    <!-- Dua Kolom -->
    <div class="two-columns">
        <div class="info-card">
            <h3><i class="fas fa-shield-alt"></i> Informasi Hak Akses</h3>
            <?php if ($current_user['role'] === 'Admin'): ?>
                <p>Admin dapat mengelola seluruh data berikut:</p>
                <ul class="access-list">
                    <li><i class="fas fa-tags"></i> Data produk</li>
                    <li><i class="fas fa-user-friends"></i> Data pelanggan</li>
                    <li><i class="fas fa-users"></i> Data sales / user</li>
                    <li><i class="fas fa-shopping-cart"></i> Sales order</li>
                    <li><i class="fas fa-chart-pie"></i> Laporan penjualan</li>
                </ul>
            <?php elseif ($current_user['role'] === 'Sales'): ?>
                <p>Sales hanya dapat membuat dan melihat sales order miliknya sendiri.</p>
            <?php else: ?>
                <p>Manager hanya melihat dashboard dan laporan secara read-only.</p>
            <?php endif; ?>
        </div>
        <div class="chart-card">
            <h3><i class="fas fa-chart-simple"></i> Tren Penjualan (Rp Juta)</h3>
            <canvas id="salesChart"></canvas>
        </div>
    </div>

    <!-- Order Terbaru -->
    <?php if($current_user['role'] !== 'Manager'): ?>
    <div class="section-title"><i class="fas fa-clock"></i> Order Terbaru</div>
    <div class="table-wrapper">
        <div style="display: flex; justify-content: space-between; align-items: center; padding: 16px 20px;">
            <span><strong><i class="fas fa-receipt"></i> Daftar transaksi terbaru</strong></span>
            <a class="btn-sm" href="<?php echo e(url('orders/create')); ?>"><i class="fas fa-plus"></i> Buat Order</a>
        </div>
        <table>
            <thead>
                <tr><th>NO ORDER</th><th>TANGGAL</th><th>PELANGGAN</th><th>TOTAL</th><th>STATUS</th><th></th></tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td><a href="<?php echo e(url('orders/detail&id=' . $order->id_order)); ?>" style="text-decoration: none; font-weight: 500; color:#1e4a76;"><?php echo e($order->no_order); ?></a></td>
                    <td><?php echo e($order->tanggal_order); ?></td>
                    <td><?php echo e($order->nama_pelanggan); ?></td>
                    <td><?php echo e(rupiah($order->total_harga)); ?></td>
                    <td><span class="status-badge <?php echo e(strtolower($order->status)); ?>"><?php echo e($order->status); ?></span></td>
                    <td><a class="btn-sm" href="<?php echo e(url('orders/detail&id=' . $order->id_order)); ?>">Detail</a></td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($orders)): ?>
                <tr><td colspan="6" style="text-align:center; padding:40px;">Belum ada order.<?php echo e(''); ?></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <footer><i class="fas fa-lock"></i> Hak akses <?php echo e($current_user['role']); ?> terverifikasi | PT Maju Jaya</footer>
</div>

<script>
    const ctx = document.getElementById('salesChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei'],
            datasets: [{
                label: 'Omzet (Rp Juta)',
                data: [8.0, 9.2, 7.5, 11.0, <?php echo e(round($cards->total_penjualan / 1000000, 1)); ?>],
                backgroundColor: 'rgba(44, 125, 160, 0.7)',
                borderRadius: 12
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: { y: { beginAtZero: true, title: { display: true, text: 'Juta Rupiah' } } }
        }
    });
</script>
</body>
</html>