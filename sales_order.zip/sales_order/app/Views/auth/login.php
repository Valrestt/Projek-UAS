<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pt. Maju Jaya</title>

    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            background-color: #0b0f19;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            font-family: 'Plus Jakarta Sans', 'Poppins', sans-serif;
            height: 100vh;
            margin: 0;
            overflow: hidden;
            position: relative;
        }

        /* ----------------------------------------------------
           VIDEO WALLPAPER LAYER & OVERLAY DUST/DARKNESS
        ---------------------------------------------------- */
        .video-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            z-index: -2;
            pointer-events: none;
        }

        /* Lapisan peredam kecerahan video agar text form tetap kontras */
        .video-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, rgba(11, 15, 25, 0.88), rgba(30, 27, 75, 0.82));
            background-image: 
                radial-gradient(at 0% 0%, rgba(37, 99, 235, 0.1) 0px, transparent 50%),
                radial-gradient(at 100% 100%, rgba(79, 70, 229, 0.1) 0px, transparent 50%);
            z-index: -1;
        }

        h1 {
            font-weight: 800;
            margin: 0;
            color: #ffffff;
            letter-spacing: -0.5px;
        }

        p {
            font-size: 14px;
            font-weight: 400;
            line-height: 24px;
            color: #94a3b8;
            margin: 15px 0 25px;
        }

        a {
            color: #60a5fa;
            font-size: 14px;
            text-decoration: none;
            transition: color 0.2s;
        }

        a:hover {
            color: #3b82f6;
        }

        button {
            border-radius: 14px;
            border: none;
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: #ffffff;
            font-size: 13px;
            font-weight: 700;
            padding: 16px 45px;
            letter-spacing: 0.5px;
            transition: all 0.3s ease;
            cursor: pointer;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        }

        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4);
        }

        button:active {
            transform: translateY(0);
        }

        button.ghost {
            background: transparent;
            border: 2px solid rgba(255, 255, 255, 0.4);
            box-shadow: none;
        }

        button.ghost:hover {
            border-color: #ffffff;
            background: rgba(255, 255, 255, 0.05);
            box-shadow: none;
        }

        form, .profile-wrapper {
            background-color: rgba(17, 24, 39, 0.9); /* Sedikit lebih transparan agar video samar menembus */
            backdrop-filter: blur(8px); /* Efek kaca halus */
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 0 50px;
            height: 100%;
            text-align: center;
            position: relative;
        }

        /* ----------------------------------------------------
           EFEK KILAUAN MEWAH (SHIMMER GLEAM GLOW EFFECT)
        ---------------------------------------------------- */
        .premium-glow-card {
            position: relative;
            overflow: hidden;
        }

        .premium-glow-card::after {
            content: '';
            position: absolute;
            top: -50%;
            left: -60%;
            width: 30%;
            height: 200%;
            background: linear-gradient(
                to right,
                rgba(255, 255, 255, 0) 0%,
                rgba(255, 255, 255, 0.03) 30%,
                rgba(255, 255, 255, 0.15) 50%,
                rgba(255, 255, 255, 0.03) 70%,
                rgba(255, 255, 255, 0) 100%
            );
            transform: rotate(25deg);
            animation: gleam-sweep 4.5s infinite ease-in-out;
            pointer-events: none;
        }

        @keyframes gleam-sweep {
            0% { left: -70%; }
            30% { left: 130%; }
            100% { left: 130%; }
        }

        /* ----------------------------------------------------
        BIODATA PEMILIK STYLE (YON PRASETYO)
        ---------------------------------------------------- */
        .avatar-container {
            position: relative;
            margin-bottom: 15px;
        }

        .avatar-frame {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            background: linear-gradient(135deg, #3b82f6, #818cf8);
            padding: 3px;
            box-shadow: 0 0 20px rgba(59, 130, 246, 0.4);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .avatar-frame i {
            font-size: 45px;
            color: #ffffff;
        }

        .verified-badge {
            position: absolute;
            bottom: 2px;
            right: 2px;
            background: #2563eb;
            color: white;
            width: 26px;
            height: 26px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            border: 2px solid #111827;
            box-shadow: 0 2px 5px rgba(0,0,0,0.3);
        }

        .profile-name {
            font-size: 24px;
            font-weight: 800;
            color: #ffffff;
            margin: 5px 0 2px 0;
            letter-spacing: -0.3px;
        }

        .profile-tag {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: #60a5fa;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .bio-info-box {
            width: 100%;
            background: rgba(31, 41, 55, 0.6);
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 16px;
            padding: 16px;
            margin-bottom: 20px;
            text-align: left;
        }

        .bio-item {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 12px;
            font-size: 13.5px;
            color: #e2e8f0;
        }

        .bio-item:last-child {
            margin-bottom: 0;
        }

        .bio-item i {
            color: #3b82f6;
            width: 18px;
            text-align: center;
            font-size: 15px;
        }

        .bio-item span.label {
            color: #64748b;
            width: 75px;
            font-size: 12px;
        }

        .stats-row {
            display: flex;
            width: 100%;
            gap: 10px;
            margin-bottom: 25px;
        }

        .stat-card {
            flex: 1;
            background: rgba(255, 255, 255, 0.02);
            border: 1px solid rgba(255, 255, 255, 0.03);
            border-radius: 12px;
            padding: 10px;
        }

        .stat-card div:first-child {
            font-size: 16px;
            font-weight: 700;
            color: #ffffff;
        }

        .stat-card div:last-child {
            font-size: 11px;
            color: #64748b;
            margin-top: 2px;
        }

        /* ----------------------------------------------------
        INPUT GRUP
        ---------------------------------------------------- */
        .input-group {
            position: relative;
            width: 100%;
            margin: 8px 0;
        }

        .input-group i {
            position: absolute;
            left: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 16px;
            transition: color 0.25s;
        }

        input {
            background-color: #1f2937;
            border: 1px solid rgba(255, 255, 255, 0.05);
            border-radius: 14px;
            padding: 16px 20px 16px 50px;
            width: 100%;
            font-size: 14px;
            color: #ffffff;
            font-family: 'Plus Jakarta Sans', sans-serif;
            transition: all 0.25s ease;
        }

        input::placeholder {
            color: #64748b;
        }

        input:focus {
            outline: none;
            border-color: #3b82f6;
            box-shadow: 0 0 0 4px rgba(59, 130, 246, 0.15);
        }

        input:focus + i {
            color: #3b82f6;
        }

        .container {
            background-color: rgba(17, 24, 39, 0.6);
            backdrop-filter: blur(16px);
            border-radius: 30px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
            position: relative;
            overflow: hidden;
            width: 1050px;
            max-width: 100%;
            min-height: 680px;
            border: 1px solid rgba(255, 255, 255, 0.08);
        }

        .form-container {
            position: absolute;
            top: 0;
            height: 100%;
            transition: all 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .sign-in-container {
            left: 0;
            width: 50%;
            z-index: 2;
        }

        .container.right-panel-active .sign-in-container {
            transform: translateX(100%);
        }

        .sign-up-container {
            left: 0;
            width: 50%;
            opacity: 0;
            z-index: 1;
        }

        .container.right-panel-active .sign-up-container {
            transform: translateX(100%);
            opacity: 1;
            z-index: 5;
            animation: show 0.6s;
        }

        @keyframes show {
            0%, 49.99% { opacity: 0; z-index: 1; }
            50%, 100% { opacity: 1; z-index: 5; }
        }

        .overlay-container {
            position: absolute;
            top: 0;
            left: 50%;
            width: 50%;
            height: 100%;
            overflow: hidden;
            transition: transform 0.6s ease-in-out;
            z-index: 100;
            border-left: 1px solid rgba(255, 255, 255, 0.05);
        }

        .container.right-panel-active .overlay-container {
            transform: translateX(-100%);
        }

        .overlay {
            background: linear-gradient(145deg, rgba(15, 23, 42, 0.9), rgba(30, 27, 75, 0.9));
            color: #ffffff;
            position: relative;
            left: -100%;
            height: 100%;
            width: 200%;
            transform: translateX(0);
            transition: transform 0.6s ease-in-out;
        }

        .container.right-panel-active .overlay {
            transform: translateX(50%);
        }

        .overlay-panel {
            position: absolute;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 0 60px;
            text-align: center;
            top: 0;
            height: 100%;
            width: 50%;
            transform: translateX(0);
            transition: transform 0.6s ease-in-out;
        }

        .overlay-left { transform: translateX(-20%); }
        .container.right-panel-active .overlay-left { transform: translateX(0); }
        .overlay-right { right: 0; transform: translateX(0); }
        .container.right-panel-active .overlay-right { transform: translateX(20%); }

        .social-container {
            margin: 15px 0 10px;
            display: flex;
            gap: 12px;
        }

        .social-container a {
            border-radius: 14px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            height: 46px;
            width: 46px;
            background: #1f2937;
            color: #ffffff;
            font-size: 16px;
            transition: all 0.2s ease;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }

        .social-container a:hover {
            background: linear-gradient(135deg, #2563eb, #4f46e5);
            color: #ffffff;
            transform: translateY(-3px);
            box-shadow: 0 6px 15px rgba(37, 99, 235, 0.3);
            border-color: transparent;
        }

        .divider-text {
            display: flex;
            align-items: center;
            gap: 15px;
            width: 100%;
            margin-bottom: 20px;
            color: #64748b;
            font-size: 13px;
        }

        .divider-text::before, .divider-text::after {
            content: "";
            flex: 1;
            height: 1px;
            background: rgba(255, 255, 255, 0.1);
        }

        .forgot-link {
            width: 100%;
            text-align: right;
            margin: 10px 0 20px;
        }

        .forgot-link a { color: #64748b; font-size: 13px; }
        .forgot-link a:hover { color: #ffffff; }

        .btn-login {
            width: 100%;
            padding: 16px;
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            border-radius: 14px;
        }

        .brand-title {
            font-family: 'Poppins', sans-serif;
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(to right, #ffffff, #94a3b8);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 5px;
        }

        .brand-tagline {
            font-size: 0.95rem;
            color: #60a5fa;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            body { height: auto; min-height: 100vh; padding: 20px; overflow-y: auto; }
            .container { width: 100%; min-height: auto; border-radius: 24px; }
            .form-container { position: relative; width: 100%; height: auto; }
            .sign-in-container, .sign-up-container { position: relative; width: 100%; left: 0; opacity: 1; transform: none !important; z-index: 1; }
            .sign-up-container { display: none; }
            .container.right-panel-active .sign-up-container { display: block; }
            .container.right-panel-active .sign-in-container { display: none; }
            form, .profile-wrapper { padding: 45px 25px; }
            .overlay-container { display: none; }
        }
    </style>
</head>

<body>

<!-- NOVELTY ELEMENT: VIDEO BACKGROUND WALLPAPER LAYER -->
<video autoplay loop muted playsinline class="video-background">
    <source src="public/videos/background.mp4" type="video/mp4">
</video>

<div class="video-overlay"></div>

<div class="container" id="container">

    <div class="form-container sign-up-container">
        <div class="profile-wrapper premium-glow-card">
            
            <div class="avatar-container">
                <div class="avatar-frame">
                    <i class="fas fa-user-tie"></i>
                </div>
                <div class="verified-badge">
                    <i class="fas fa-check"></i>
                </div>
            </div>

            <div class="profile-name">Yon Prasetyo</div>
            <div class="profile-tag">Founder & Chief Architect</div>

            <div class="bio-info-box">
                <div class="bio-item">
                    <i class="fas fa-id-badge"></i>
                    <span class="label">Brand</span>
                    <strong>Valrest Indonesia</strong>
                </div>
                <div class="bio-item">
                    <i class="fas fa-graduation-cap"></i>
                    <span class="label">Status</span>
                    <strong>Systems Analyst & Dev</strong>
                </div>
                <div class="bio-item">
                    <i class="fas fa-code"></i>
                    <span class="label">Expertise</span>
                    <strong>Laravel / PHP / UIUX</strong>
                </div>
                <div class="bio-item">
                    <i class="fas fa-quote-left"></i>
                    <span class="label">Motto</span>
                    <em style="color: #60a5fa;">"Stay Warm, Stay Confident"</em>
                </div>
            </div>

            <div class="stats-row">
                <div class="stat-card">
                    <div>v2.4</div>
                    <div>System Build</div>
                </div>
                <div class="stat-card">
                    <div>100%</div>
                    <div>Secure Core</div>
                </div>
                <div class="stat-card">
                    <div>Active</div>
                    <div>Platform State</div>
                </div>
            </div>

            <div class="divider-text">hubungi pengembang</div>

            <div class="social-container">
                <a href="#" title="GitHub"><i class="fab fa-github"></i></a>
                <a href="#" title="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
            </div>

            <a href="#" id="mobileLogin" style="margin-top: 15px; display: block; font-size: 13px;">← Kembali ke Halaman Login</a>
        </div>
    </div>

    <div class="form-container sign-in-container">
        <form method="post" action="<?php echo e(url('auth/process')); ?>" class="premium-glow-card">
            <?php echo csrf_input(); ?>

            <h1>SELAMAT DATANG</h1>
            <p style="margin-bottom: 10px;">Silakan masuk untuk mengelola sales order</p>

            <div class="social-container">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-google"></i></a>
                <a href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>

            <div class="divider-text">atau gunakan akun terdaftar</div>

            <?php if (!empty($flash)): ?>
                <div class="alert <?php echo e($flash['type']); ?>">
                    <i class="fas <?php echo e($flash['type'] == 'success' ? 'fa-check-circle' : 'fa-exclamation-triangle'); ?>"></i>
                    <?php echo e($flash['message']); ?>
                </div>
            <?php endif; ?>

            <div class="input-group">
                <input type="text" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username atau Email" required autofocus>
                <i class="fas fa-user"></i>
            </div>

            <div class="input-group">
                <input type="password" name="password" placeholder="Kata Sandi" required>
                <i class="fas fa-lock"></i>
            </div>

            <div class="forgot-link">
                <a href="#">Lupa password?</a>
            </div>

            <button type="submit" class="btn-login">
                <i class="fas fa-sign-in-alt"></i> LOGIN
            </button>

            <a href="#" id="mobileRegister" style="margin-top: 25px; display: block;">Lihat Profil Pengembang</a>
        </form>
    </div>

    <div class="overlay-container">
        <div class="overlay">

            <div class="overlay-panel overlay-left">
                <div class="brand-title">Valrest</div>
                <div class="brand-tagline">Stay Warm, Stay Confident</div>
                <p style="color: #cbd5e1; margin-top: 20px;">Gunakan akun resmi manajemen internal Anda untuk masuk kembali ke sistem dashboard operasional sales order.</p>
                <button class="ghost" id="signIn" style="margin-top: 10px;">KEMBALI LOGIN</button>
            </div>

            <div class="overlay-panel overlay-right">
                <div class="brand-title">Valrest</div>
                <div class="brand-tagline" style="margin-bottom: 15px;">Stay Warm, Stay Confident</div>
                <p style="color: #cbd5e1; max-width: 340px;">Sistem manajemen internal koordinasi sales order terintegrasi eksklusif PT Maju Jaya.</p>
                <button class="ghost" id="signUp" style="margin-top: 15px;">
                    <i class="fas fa-user-shield" style="margin-right: 5px;"></i> LIHAT PROFIL
                </button>
            </div>

        </div>
    </div>

</div>

<script>
    const signUpButton = document.getElementById('signUp');
    const signInButton = document.getElementById('signIn');
    const mobileRegister = document.getElementById('mobileRegister');
    const mobileLogin = document.getElementById('mobileLogin');
    const container = document.getElementById('container');

    signUpButton.addEventListener('click', function () {
        container.classList.add('right-panel-active');
    });

    signInButton.addEventListener('click', function () {
        container.classList.remove('right-panel-active');
    });

    mobileRegister.addEventListener('click', function (e) {
        e.preventDefault();
        container.classList.add('right-panel-active');
    });

    mobileLogin.addEventListener('click', function (e) {
        e.preventDefault();
        container.classList.remove('right-panel-active');
    });
</script>

</body>
</html>