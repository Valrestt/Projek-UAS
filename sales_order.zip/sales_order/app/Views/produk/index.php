<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>Data Produk | <?php echo e($app_name ?? 'Sales Order'); ?></title>
    <!-- Google Fonts + Font Awesome -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #f0f4ff, #e9f0fa, #fef2f8, #e6f7f0);
            background-size: 400% 400%;
            animation: gradientShift 15s ease infinite;
            min-height: 100vh;
            padding: 30px 35px;
        }

        @keyframes gradientShift {
            0% { background-position: 0% 0%; }
            25% { background-position: 100% 0%; }
            50% { background-position: 100% 100%; }
            75% { background-position: 0% 100%; }
            100% { background-position: 0% 0%; }
        }

        /* Overlay noise halus */
        body::before {
            content: "";
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48ZmlsdGVyIGlkPSJmIj48ZmVUdXJidWxlbmNlIHR5cGU9ImZyYWN0YWxOb2lzZSIgYmFzZUZyZXF1ZW5jeT0iLjciIG51bU9jdGF2ZXM9IjMiLz48L2ZpbHRlcj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWx0ZXI9InVybCgjZikiIG9wYWNpdHk9IjAuMDYiLz48L3N2Zz4=');
            background-repeat: repeat;
            pointer-events: none;
            z-index: 0;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            position: relative;
            z-index: 2;
        }

        /* Header halaman dengan efek glass */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
            background: rgba(255,255,255,0.7);
            backdrop-filter: blur(12px);
            padding: 20px 28px;
            border-radius: 32px;
            box-shadow: 0 20px 35px -12px rgba(0,0,0,0.1);
            border: 1px solid rgba(255,255,255,0.6);
        }

        .page-header h1 {
            font-size: 1.9rem;
            font-weight: 800;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            margin-bottom: 6px;
        }

        .page-header p {
            color: #4a627a;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .page-header p i {
            color: #3b82f6;
        }

        /* Tombol tambah produk */
        .btn-add {
            background: linear-gradient(135deg, #3b82f6, #1e3a8a);
            color: white;
            border: none;
            padding: 12px 28px;
            border-radius: 40px;
            font-weight: 700;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
            transition: 0.2s;
            box-shadow: 0 12px 20px -8px rgba(59,130,246,0.4);
        }

        .btn-add:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 30px -10px rgba(59,130,246,0.6);
        }

        /* Card tabel */
        .table-wrap {
            background: rgba(255,255,255,0.85);
            backdrop-filter: blur(12px);
            border-radius: 32px;
            padding: 20px 0 20px 0;
            box-shadow: 0 25px 45px -12px rgba(0,0,0,0.15);
            border: 1px solid rgba(255,255,255,0.6);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 12px;
            font-size: 0.9rem;
        }

        th {
            padding: 18px 20px;
            background: linear-gradient(135deg, #1e3c72, #2b4c7c);
            color: white;
            font-weight: 600;
            text-align: left;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }

        th:first-child { border-radius: 20px 0 0 20px; }
        th:last-child { border-radius: 0 20px 20px 0; }

        tbody tr {
            background: rgba(255,255,255,0.9);
            border-radius: 20px;
            transition: 0.25s;
            box-shadow: 0 12px 20px -10px rgba(0,0,0,0.08);
        }

        tbody tr:hover {
            transform: translateY(-3px);
            background: white;
            box-shadow: 0 22px 35px -12px rgba(0,0,0,0.2);
            cursor: pointer;
        }

        td {
            padding: 16px 20px;
            color: #1e2f3e;
            font-weight: 500;
        }

        /* Aksi (tombol Edit & Hapus) */
        .actions {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }

        .btn-edit, .btn-delete {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 16px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: 600;
            text-decoration: none;
            transition: 0.2s;
            border: none;
            cursor: pointer;
        }

        .btn-edit {
            background: #eef2ff;
            color: #1e40af;
            border-left: 3px solid #3b82f6;
        }

        .btn-edit:hover {
            background: #3b82f6;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 14px rgba(59,130,246,0.3);
        }

        .btn-delete {
            background: #fee2e2;
            color: #b91c1c;
            border-left: 3px solid #ef4444;
        }

        .btn-delete:hover {
            background: #ef4444;
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 14px rgba(239,68,68,0.3);
        }

        /* Empty state */
        .empty {
            text-align: center;
            padding: 60px;
            color: #5b7f95;
            font-style: italic;
        }

        /* Responsif */
        @media (max-width: 768px) {
            body {
                padding: 20px;
            }
            .page-header {
                flex-direction: column;
                align-items: stretch;
                gap: 16px;
                text-align: center;
            }
            .actions {
                flex-direction: column;
                align-items: stretch;
            }
            th, td {
                padding: 12px 16px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="page-header">
        <div>
            <h1><i class="fas fa-boxes"></i> Data Produk</h1>
            <p><i class="fas fa-tags"></i> Kelola produk, harga, dan stok.</p>
        </div>
        <a class="btn-add" href="<?php echo e(url('produk/create')); ?>">
            <i class="fas fa-plus-circle"></i> Tambah Produk
        </a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th><i class="fas fa-barcode"></i> Kode</th>
                    <th><i class="fas fa-tag"></i> Nama Produk</th>
                    <th><i class="fas fa-dollar-sign"></i> Harga</th>
                    <th><i class="fas fa-box"></i> Stok</th>
                    <th><i class="fas fa-cog"></i> Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produk as $p): ?>
                <tr>
                    <td><strong><?php echo e($p->kode_produk); ?></strong></td>
                    <td><?php echo e($p->nama_produk); ?></td>
                    <td><?php echo e(rupiah($p->harga)); ?></td>
                    <td><?php echo e($p->stok); ?></td>
                    <td class="actions">
                        <a class="btn-edit" href="<?php echo e(url('produk/edit&id=' . $p->id_produk)); ?>">
                            <i class="fas fa-edit"></i> Edit
                        </a>
                        <form method="post" action="<?php echo e(url('produk/delete')); ?>" onsubmit="return confirm('Hapus produk ini?')" style="display: inline;">
                            <?php echo csrf_input(); ?>
                            <input type="hidden" name="id" value="<?php echo e($p->id_produk); ?>">
                            <button class="btn-delete" type="submit">
                                <i class="fas fa-trash-alt"></i> Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (empty($produk)): ?>
                <tr>
                    <td colspan="5" class="empty">
                        <i class="fas fa-database"></i> Belum ada produk. Silakan tambah produk baru.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>