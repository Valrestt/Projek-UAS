<div class="page-header">
    <div>
        <h1><?php echo e($title); ?></h1>
        <p>Isi data produk dengan benar.</p>
    </div>
</div>

<?php $isEdit = !empty($produk); ?>
<form class="card form" method="post" action="<?php echo e($isEdit ? url('produk/update') : url('produk/store')); ?>">
    <?php echo csrf_input(); ?>
    <?php if ($isEdit): ?>
        <input type="hidden" name="id" value="<?php echo e($produk->id_produk); ?>">
    <?php endif; ?>

    <label>Kode Produk</label>
    <input type="text" name="kode_produk" value="<?php echo e($isEdit ? $produk->kode_produk : old('kode_produk')); ?>" required>

    <label>Nama Produk</label>
    <input type="text" name="nama_produk" value="<?php echo e($isEdit ? $produk->nama_produk : old('nama_produk')); ?>" required>

    <label>Harga</label>
    <input type="number" name="harga" min="0" step="100" value="<?php echo e($isEdit ? $produk->harga : old('harga', 0)); ?>" required>

    <label>Stok</label>
    <input type="number" name="stok" min="0" value="<?php echo e($isEdit ? $produk->stok : old('stok', 0)); ?>" required>

    <div class="form-actions">
        <a class="btn secondary" href="<?php echo e(url('produk')); ?>">Kembali</a>
        <button class="btn" type="submit">Simpan</button>
    </div>
</form>
