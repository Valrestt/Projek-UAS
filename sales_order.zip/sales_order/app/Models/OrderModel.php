<?php
class OrderModel extends BaseModel
{
    public function generateNoOrder()
    {
        $prefix = 'SO-' . date('Ymd') . '-';
        $stmt = $this->db->prepare('SELECT COUNT(*) AS total FROM sales_order WHERE no_order LIKE ?');
        $stmt->execute(array($prefix . '%'));
        $row = $stmt->fetch();
        $number = ((int) $row->total) + 1;
        return $prefix . str_pad($number, 4, '0', STR_PAD_LEFT);
    }

    public function allByRole($role, $idSales)
    {
        $sql = "SELECT so.*, sp.nama AS nama_sales, p.nama_pelanggan
                FROM sales_order so
                JOIN sales_person sp ON sp.id_sales = so.id_sales
                JOIN pelanggan p ON p.id_pelanggan = so.id_pelanggan";

        if ($role === 'Sales') {
            $sql .= ' WHERE so.id_sales = ?';
            $stmt = $this->db->prepare($sql . ' ORDER BY so.id_order DESC');
            $stmt->execute(array($idSales));
            return $stmt->fetchAll();
        }

        return $this->db->query($sql . ' ORDER BY so.id_order DESC')->fetchAll();
    }

    public function find($id)
    {
        $sql = "SELECT so.*, sp.nama AS nama_sales, p.nama_pelanggan, p.alamat, p.no_telp
                FROM sales_order so
                JOIN sales_person sp ON sp.id_sales = so.id_sales
                JOIN pelanggan p ON p.id_pelanggan = so.id_pelanggan
                WHERE so.id_order = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array($id));
        return $stmt->fetch();
    }

    public function details($idOrder)
    {
        $sql = "SELECT do.*, pr.kode_produk, pr.nama_produk
                FROM detail_order do
                JOIN produk pr ON pr.id_produk = do.id_produk
                WHERE do.id_order = ?
                ORDER BY do.id_detail ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute(array($idOrder));
        return $stmt->fetchAll();
    }

    public function canAccess($order, $user)
    {
        if (!$order || !$user) {
            return false;
        }
        if ($user['role'] === 'Admin') {
            return true;
        }
        if ($user['role'] === 'Sales' && (int) $order->id_sales === (int) $user['id_sales']) {
            return true;
        }
        return false;
    }

    public function create($header, $items)
    {
        $produkModel = new ProdukModel();

        try {
            $this->db->beginTransaction();

            $total = 0;
            $cleanItems = array();

            foreach ($items as $item) {
                $idProduk = isset($item['id_produk']) ? (int) $item['id_produk'] : 0;
                $jumlah = isset($item['jumlah']) ? (int) $item['jumlah'] : 0;

                if ($idProduk <= 0 || $jumlah <= 0) {
                    continue;
                }

                // Harga dan stok diambil ulang dari database agar tidak dapat dimanipulasi melalui browser.
                $produk = $produkModel->find($idProduk);
                if (!$produk) {
                    throw new Exception('Produk tidak ditemukan.');
                }

                if ((int) $produk->stok < $jumlah) {
                    throw new Exception('Stok produk ' . $produk->nama_produk . ' tidak cukup.');
                }

                $subtotal = (float) $produk->harga * $jumlah;
                $total += $subtotal;

                $cleanItems[] = array(
                    'id_produk'    => $idProduk,
                    'jumlah'       => $jumlah,
                    'harga_satuan' => $produk->harga,
                    'subtotal'     => $subtotal
                );
            }

            if (empty($cleanItems)) {
                throw new Exception('Minimal pilih satu produk.');
            }

            $sql = 'INSERT INTO sales_order (no_order, id_sales, id_pelanggan, tanggal_order, total_harga, status)
                    VALUES (?, ?, ?, ?, ?, ?)';
            $stmt = $this->db->prepare($sql);
            $stmt->execute(array(
                $this->generateNoOrder(),
                $header['id_sales'],
                $header['id_pelanggan'],
                $header['tanggal_order'],
                $total,
                'draft'
            ));

            $idOrder = $this->db->lastInsertId();

            $detailSql = 'INSERT INTO detail_order (id_order, id_produk, jumlah, harga_satuan, subtotal)
                          VALUES (?, ?, ?, ?, ?)';
            $detailStmt = $this->db->prepare($detailSql);

            foreach ($cleanItems as $detail) {
                $detailStmt->execute(array(
                    $idOrder,
                    $detail['id_produk'],
                    $detail['jumlah'],
                    $detail['harga_satuan'],
                    $detail['subtotal']
                ));

                if (!$produkModel->decreaseStock($detail['id_produk'], $detail['jumlah'])) {
                    throw new Exception('Gagal mengurangi stok produk.');
                }
            }

            $this->db->commit();

            return array('success' => true, 'id_order' => $idOrder, 'message' => 'Order berhasil dibuat.');
        } catch (Exception $e) {
            if ($this->db->inTransaction()) {
                $this->db->rollBack();
            }
            return array('success' => false, 'message' => $e->getMessage());
        }
    }

    public function updateStatus($idOrder, $status)
    {
        $allowed = array('draft', 'dikirim', 'selesai', 'dibatalkan');
        if (!in_array($status, $allowed)) {
            return false;
        }

        $stmt = $this->db->prepare('UPDATE sales_order SET status = ? WHERE id_order = ?');
        return $stmt->execute(array($status, $idOrder));
    }
}
