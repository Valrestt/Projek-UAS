<?php
class UserModel extends BaseModel
{
    public function findByUsername($username)
    {
        $stmt = $this->db->prepare('SELECT * FROM sales_person WHERE username = ? LIMIT 1');
        $stmt->execute(array($username));
        return $stmt->fetch();
    }

    public function all()
    {
        return $this->db->query('SELECT * FROM sales_person ORDER BY id_sales DESC')->fetchAll();
    }

    public function salesOnly()
    {
        return $this->db->query("SELECT * FROM sales_person WHERE role = 'Sales' ORDER BY nama ASC")->fetchAll();
    }

    public function find($id)
    {
        $stmt = $this->db->prepare('SELECT * FROM sales_person WHERE id_sales = ?');
        $stmt->execute(array($id));
        return $stmt->fetch();
    }

    public function create($data)
    {
        $sql = 'INSERT INTO sales_person (nama, username, password, role) VALUES (?, ?, ?, ?)';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array(
            $data['nama'],
            $data['username'],
            password_hash($data['password'], PASSWORD_BCRYPT),
            $data['role']
        ));
    }

    public function update($id, $data)
    {
        if (!empty($data['password'])) {
            $sql = 'UPDATE sales_person SET nama = ?, username = ?, password = ?, role = ? WHERE id_sales = ?';
            $stmt = $this->db->prepare($sql);
            return $stmt->execute(array(
                $data['nama'],
                $data['username'],
                password_hash($data['password'], PASSWORD_BCRYPT),
                $data['role'],
                $id
            ));
        }

        $sql = 'UPDATE sales_person SET nama = ?, username = ?, role = ? WHERE id_sales = ?';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array($data['nama'], $data['username'], $data['role'], $id));
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare('DELETE FROM sales_person WHERE id_sales = ?');
        return $stmt->execute(array($id));
    }
}
