<?php
class ProdukModel extends BaseModel
{
    public function all()
    {
        return $this->db->query('SELECT * FROM produk ORDER BY id_produk DESC')->fetchAll();
    }

    public function available()
    {
        return $this->db->query('SELECT * FROM produk WHERE stok > 0 ORDER BY nama_produk ASC')->fetchAll();
    }

    public function find($id)
    {
        $stmt = $this->db->prepare('SELECT * FROM produk WHERE id_produk = ?');
        $stmt->execute(array($id));
        return $stmt->fetch();
    }

    public function create($data)
    {
        $sql = 'INSERT INTO produk (kode_produk, nama_produk, harga, stok) VALUES (?, ?, ?, ?)';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array($data['kode_produk'], $data['nama_produk'], $data['harga'], $data['stok']));
    }

    public function update($id, $data)
    {
        $sql = 'UPDATE produk SET kode_produk = ?, nama_produk = ?, harga = ?, stok = ? WHERE id_produk = ?';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array($data['kode_produk'], $data['nama_produk'], $data['harga'], $data['stok'], $id));
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare('DELETE FROM produk WHERE id_produk = ?');
        return $stmt->execute(array($id));
    }

    public function decreaseStock($idProduk, $jumlah)
    {
        $stmt = $this->db->prepare('UPDATE produk SET stok = stok - ? WHERE id_produk = ? AND stok >= ?');
        $stmt->execute(array($jumlah, $idProduk, $jumlah));
        return $stmt->rowCount() > 0;
    }
}
