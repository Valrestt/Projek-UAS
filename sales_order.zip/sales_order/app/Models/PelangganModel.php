<?php
class PelangganModel extends BaseModel
{
    public function all()
    {
        return $this->db->query('SELECT * FROM pelanggan ORDER BY id_pelanggan DESC')->fetchAll();
    }

    public function find($id)
    {
        $stmt = $this->db->prepare('SELECT * FROM pelanggan WHERE id_pelanggan = ?');
        $stmt->execute(array($id));
        return $stmt->fetch();
    }

    public function create($data)
    {
        $sql = 'INSERT INTO pelanggan (nama_pelanggan, alamat, no_telp) VALUES (?, ?, ?)';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array($data['nama_pelanggan'], $data['alamat'], $data['no_telp']));
    }

    public function update($id, $data)
    {
        $sql = 'UPDATE pelanggan SET nama_pelanggan = ?, alamat = ?, no_telp = ? WHERE id_pelanggan = ?';
        $stmt = $this->db->prepare($sql);
        return $stmt->execute(array($data['nama_pelanggan'], $data['alamat'], $data['no_telp'], $id));
    }

    public function delete($id)
    {
        $stmt = $this->db->prepare('DELETE FROM pelanggan WHERE id_pelanggan = ?');
        return $stmt->execute(array($id));
    }
}
