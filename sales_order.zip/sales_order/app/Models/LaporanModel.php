<?php
class LaporanModel extends BaseModel
{
    private function dateWhere($alias, $start, $end, &$params)
    {
        $where = " WHERE {$alias}.status = 'selesai'";
        if (!empty($start)) {
            $where .= " AND {$alias}.tanggal_order >= ?";
            $params[] = $start;
        }
        if (!empty($end)) {
            $where .= " AND {$alias}.tanggal_order <= ?";
            $params[] = $end;
        }
        return $where;
    }

    public function cards($start = '', $end = '')
    {
        $params = array();
        $where = $this->dateWhere('so', $start, $end, $params);

        $sql = "SELECT COUNT(*) AS total_order,
                       COALESCE(SUM(total_harga), 0) AS total_penjualan
                FROM sales_order so {$where}";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetch();
    }

    public function perSales($start = '', $end = '')
    {
        $params = array();
        $where = $this->dateWhere('so', $start, $end, $params);
        $sql = "SELECT sp.nama AS nama_sales,
                       COUNT(so.id_order) AS jumlah_order,
                       COALESCE(SUM(so.total_harga), 0) AS total_penjualan
                FROM sales_order so
                JOIN sales_person sp ON sp.id_sales = so.id_sales
                {$where}
                GROUP BY sp.id_sales, sp.nama
                ORDER BY total_penjualan DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function perProduk($start = '', $end = '')
    {
        $params = array();
        $where = $this->dateWhere('so', $start, $end, $params);
        $sql = "SELECT pr.kode_produk, pr.nama_produk,
                       SUM(do.jumlah) AS jumlah_terjual,
                       SUM(do.subtotal) AS total_penjualan
                FROM detail_order do
                JOIN produk pr ON pr.id_produk = do.id_produk
                JOIN sales_order so ON so.id_order = do.id_order
                {$where}
                GROUP BY pr.id_produk, pr.kode_produk, pr.nama_produk
                ORDER BY jumlah_terjual DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function perPeriode($start = '', $end = '')
    {
        $params = array();
        $where = $this->dateWhere('so', $start, $end, $params);
        $sql = "SELECT so.tanggal_order,
                       COUNT(so.id_order) AS jumlah_order,
                       SUM(so.total_harga) AS total_penjualan
                FROM sales_order so
                {$where}
                GROUP BY so.tanggal_order
                ORDER BY so.tanggal_order ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }
}
