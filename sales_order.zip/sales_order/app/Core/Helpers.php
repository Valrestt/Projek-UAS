<?php
function config_item($file, $key = null)
{
    $path = ROOT_PATH . '/config/' . $file . '.php';
    $config = file_exists($path) ? require $path : array();
    if ($key === null) {
        return $config;
    }
    return isset($config[$key]) ? $config[$key] : null;
}

function base_url($path = '')
{
    $app = config_item('app');
    if (!empty($app['base_url'])) {
        return rtrim($app['base_url'], '/') . '/' . ltrim($path, '/');
    }

    $scriptName = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
    $scriptName = rtrim($scriptName, '/');
    if ($scriptName === '') {
        $scriptName = '';
    }

    return $scriptName . '/' . ltrim($path, '/');
}

function url($route = '')
{
    return base_url('index.php') . ($route !== '' ? '?r=' . $route : '');
}

function asset($path)
{
    return base_url('public/assets/' . ltrim($path, '/'));
}

function redirect_url($route = '')
{
    header('Location: ' . url($route));
    exit;
}

function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function rupiah($number)
{
    return 'Rp ' . number_format((float) $number, 0, ',', '.');
}

function csrf_token()
{
    if (empty($_SESSION['_csrf_token'])) {
        $_SESSION['_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['_csrf_token'];
}

function csrf_input()
{
    return '<input type="hidden" name="_csrf_token" value="' . e(csrf_token()) . '">';
}

function set_flash($type, $message)
{
    $_SESSION['flash'] = array('type' => $type, 'message' => $message);
}

function get_flash()
{
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function selected($current, $expected)
{
    return ((string) $current === (string) $expected) ? 'selected' : '';
}

function old($key, $default = '')
{
    if (isset($_SESSION['_old'][$key])) {
        return $_SESSION['_old'][$key];
    }
    return $default;
}

function set_old($data)
{
    $_SESSION['_old'] = $data;
}

function clear_old()
{
    if (isset($_SESSION['_old'])) {
        unset($_SESSION['_old']);
    }
}
