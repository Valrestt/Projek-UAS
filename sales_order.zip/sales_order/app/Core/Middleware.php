<?php
class Middleware
{
    public static function isLoggedIn()
    {
        return isset($_SESSION['user']) && !empty($_SESSION['user']['logged_in']);
    }

    public static function user()
    {
        return self::isLoggedIn() ? $_SESSION['user'] : null;
    }

    public static function requireLogin()
    {
        if (!self::isLoggedIn()) {
            set_flash('error', 'Silakan login terlebih dahulu.');
            redirect_url('auth/login');
        }
    }

    public static function requireRole($roles)
    {
        self::requireLogin();
        $user = self::user();

        if (!in_array($user['role'], $roles)) {
            http_response_code(403);
            echo '<h2>Akses ditolak</h2><p>Role Anda tidak memiliki izin untuk membuka halaman ini.</p>';
            echo '<p><a href="' . e(url('dashboard')) . '">Kembali ke Dashboard</a></p>';
            exit;
        }
    }
}
