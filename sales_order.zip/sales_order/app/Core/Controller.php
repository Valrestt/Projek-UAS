<?php
class Controller
{
    protected function view($view, $data = array())
    {
        $data['app_name'] = config_item('app', 'app_name');
        $data['current_user'] = Middleware::user();
        $data['flash'] = get_flash();
        extract($data);

        $viewFile = APP_PATH . '/Views/' . $view . '.php';
        if (!file_exists($viewFile)) {
            throw new Exception('View tidak ditemukan: ' . $view);
        }

        require APP_PATH . '/Views/layout/header.php';
        require APP_PATH . '/Views/layout/sidebar.php';
        require $viewFile;
        require APP_PATH . '/Views/layout/footer.php';
        clear_old();
    }

    protected function viewOnly($view, $data = array())
    {
        $data['app_name'] = config_item('app', 'app_name');
        $data['flash'] = get_flash();
        extract($data);
        require APP_PATH . '/Views/' . $view . '.php';
        clear_old();
    }

    protected function request($key, $default = null)
    {
        if (isset($_POST[$key])) {
            return is_array($_POST[$key]) ? $_POST[$key] : trim($_POST[$key]);
        }
        if (isset($_GET[$key])) {
            return is_array($_GET[$key]) ? $_GET[$key] : trim($_GET[$key]);
        }
        return $default;
    }

    protected function verifyCsrf()
    {
        $token = isset($_POST['_csrf_token']) ? $_POST['_csrf_token'] : '';
        if (empty($_SESSION['_csrf_token']) || !hash_equals($_SESSION['_csrf_token'], $token)) {
            http_response_code(419);
            echo 'Token keamanan tidak valid. Silakan refresh halaman.';
            exit;
        }
    }
}
