<?php
class Database
{
    private static $instance = null;

    public static function connect()
    {
        if (self::$instance === null) {
            $config = config_item('database');
            $dsn = 'mysql:host=' . $config['host'] . ';dbname=' . $config['database'] . ';charset=' . $config['charset'];

            self::$instance = new PDO($dsn, $config['username'], $config['password'], array(
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ,
                PDO::ATTR_EMULATE_PREPARES => false
            ));
        }

        return self::$instance;
    }
}
