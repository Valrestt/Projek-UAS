<?php
class SimplePdf
{
    private $pages = array();
    private $current = array();
    private $y = 800;

    public function addLine($text)
    {
        if ($this->y < 50) {
            $this->pages[] = $this->current;
            $this->current = array();
            $this->y = 800;
        }
        $this->current[] = array('x' => 40, 'y' => $this->y, 'text' => $text);
        $this->y -= 16;
    }

    private function esc($text)
    {
        return str_replace(array('\\', '(', ')'), array('\\\\', '\\(', '\\)'), $text);
    }

    public function output($filename)
    {
        if (!empty($this->current)) {
            $this->pages[] = $this->current;
        }

        $objects = array();
        $pagesKids = array();
        $objNum = 3;

        foreach ($this->pages as $pageLines) {
            $content = "BT\n/F1 10 Tf\n";
            foreach ($pageLines as $line) {
                $content .= '1 0 0 1 ' . $line['x'] . ' ' . $line['y'] . ' Tm (' . $this->esc($line['text']) . ") Tj\n";
            }
            $content .= "ET";

            $contentObj = $objNum++;
            $pageObj = $objNum++;

            $objects[$contentObj] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "\nendstream";
            $objects[$pageObj] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 1 0 R >> >> /Contents {$contentObj} 0 R >>";
            $pagesKids[] = $pageObj . ' 0 R';
        }

        $objects[1] = '<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>';
        $objects[2] = '<< /Type /Pages /Kids [' . implode(' ', $pagesKids) . '] /Count ' . count($pagesKids) . ' >>';
        $catalogObj = $objNum++;
        $objects[$catalogObj] = '<< /Type /Catalog /Pages 2 0 R >>';

        ksort($objects);
        $pdf = "%PDF-1.4\n";
        $offsets = array();

        foreach ($objects as $num => $body) {
            $offsets[$num] = strlen($pdf);
            $pdf .= $num . " 0 obj\n" . $body . "\nendobj\n";
        }

        $xref = strlen($pdf);
        $max = max(array_keys($objects));
        $pdf .= "xref\n0 " . ($max + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $pdf .= sprintf('%010d 00000 n ', isset($offsets[$i]) ? $offsets[$i] : 0) . "\n";
        }
        $pdf .= "trailer\n<< /Size " . ($max + 1) . " /Root {$catalogObj} 0 R >>\n";
        $pdf .= "startxref\n" . $xref . "\n%%EOF";

        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $pdf;
        exit;
    }
}
