SISTEM SALES ORDER - FINAL
PHP Native MVC OOP
Kompatibel XAMPP 7.3 / PHP 7.3

CARA MENJALANKAN:

1. Extract folder sales_order_final ke:
   C:\xampp\htdocs\

   Hasil akhirnya:
   C:\xampp\htdocs\sales_order_final\index.php
   C:\xampp\htdocs\sales_order_final\app\
   C:\xampp\htdocs\sales_order_final\database\
   C:\xampp\htdocs\sales_order_final\public\

2. Jalankan XAMPP:
   - Start Apache
   - Start MySQL

3. Buka phpMyAdmin:
   http://localhost/phpmyadmin

4. Import database:
   Pilih file:
   C:\xampp\htdocs\sales_order_final\database\sales_order.sql

5. Buka website:
   http://localhost/sales_order_final/

   Jika perlu, gunakan:
   http://localhost/sales_order_final/index.php?r=auth/login

AKUN LOGIN:

Admin
Username : admin
Password : admin123

Sales
Username : sales
Password : sales123

Manager
Username : manager
Password : manager123

FITUR:
- Login session
- Role Admin, Sales, Manager
- Admin CRUD produk, pelanggan, user/sales
- Sales membuat dan melihat order miliknya sendiri
- Order multi-produk dan total otomatis
- Status order: draft, dikirim, selesai, dibatalkan
- Manager/Admin melihat laporan
- Filter laporan berdasarkan tanggal
- Cetak dan export PDF

CATATAN:
Versi ini dibuat dengan PHP Native MVC OOP agar langsung jalan tanpa harus download core CodeIgniter 3 lagi.
