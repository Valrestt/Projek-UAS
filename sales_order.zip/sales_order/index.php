<?php
session_start();

// Front Controller - Sistem Sales Order PHP Native MVC OOP
// Kompatibel dengan XAMPP 7.3 / PHP 7.3

define('ROOT_PATH', __DIR__);
define('APP_PATH', ROOT_PATH . DIRECTORY_SEPARATOR . 'app');

require_once APP_PATH . '/Core/Helpers.php';

spl_autoload_register(function ($class) {
    $folders = array('Core', 'Controllers', 'Models', 'Libraries');

    foreach ($folders as $folder) {
        $file = APP_PATH . DIRECTORY_SEPARATOR . $folder . DIRECTORY_SEPARATOR . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

$route = isset($_GET['r']) ? trim($_GET['r'], '/') : '';

if ($route === '') {
    $route = Middleware::isLoggedIn() ? 'dashboard' : 'auth/login';
}

$segments = explode('/', $route);
$controllerKey = isset($segments[0]) ? $segments[0] : 'dashboard';
$action = isset($segments[1]) ? $segments[1] : 'index';

$controllerMap = array(
    'auth'      => 'AuthController',
    'dashboard' => 'DashboardController',
    'produk'    => 'ProdukController',
    'pelanggan' => 'PelangganController',
    'sales'     => 'SalesController',
    'orders'    => 'OrderController',
    'laporan'   => 'LaporanController'
);

if (!isset($controllerMap[$controllerKey])) {
    http_response_code(404);
    echo '404 - Halaman tidak ditemukan';
    exit;
}

$controllerClass = $controllerMap[$controllerKey];
$controller = new $controllerClass();

if (!method_exists($controller, $action)) {
    http_response_code(404);
    echo '404 - Method tidak ditemukan';
    exit;
}

$controller->{$action}();
