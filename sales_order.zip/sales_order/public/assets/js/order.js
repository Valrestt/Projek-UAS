(function(){
    function rupiah(number){
        number = Number(number || 0);
        return 'Rp ' + number.toLocaleString('id-ID');
    }

    function updateRow(row){
        var select = row.querySelector('.product-select');
        var selected = select.options[select.selectedIndex];
        var harga = Number(selected.getAttribute('data-harga') || 0);
        var stok = Number(selected.getAttribute('data-stok') || 0);
        var qty = Number(row.querySelector('.qty').value || 0);

        row.querySelector('.harga').textContent = rupiah(harga);
        row.querySelector('.stok').textContent = stok;
        row.querySelector('.subtotal').textContent = rupiah(harga * qty);
    }

    function updateTotal(){
        var table = document.getElementById('orderItems');
        if (!table) return;
        var total = 0;
        table.querySelectorAll('tbody tr').forEach(function(row){
            var select = row.querySelector('.product-select');
            var selected = select.options[select.selectedIndex];
            var harga = Number(selected.getAttribute('data-harga') || 0);
            var qty = Number(row.querySelector('.qty').value || 0);
            total += harga * qty;
        });
        var grand = document.getElementById('grandTotal');
        if (grand) grand.textContent = rupiah(total);
    }

    function bindRow(row){
        row.querySelector('.product-select').addEventListener('change', function(){
            updateRow(row);
            updateTotal();
        });
        row.querySelector('.qty').addEventListener('input', function(){
            updateRow(row);
            updateTotal();
        });
        row.querySelector('.btn-remove').addEventListener('click', function(){
            var tbody = row.parentNode;
            if (tbody.querySelectorAll('tr').length > 1) {
                row.remove();
                updateTotal();
            }
        });
    }

    var table = document.getElementById('orderItems');
    if (!table) return;

    table.querySelectorAll('tbody tr').forEach(bindRow);

    var addButton = document.getElementById('addItem');
    if (addButton) {
        addButton.addEventListener('click', function(){
            var tbody = table.querySelector('tbody');
            var firstRow = tbody.querySelector('tr');
            var newRow = firstRow.cloneNode(true);
            newRow.querySelector('.product-select').selectedIndex = 0;
            newRow.querySelector('.qty').value = 1;
            newRow.querySelector('.harga').textContent = 'Rp 0';
            newRow.querySelector('.stok').textContent = '0';
            newRow.querySelector('.subtotal').textContent = 'Rp 0';
            tbody.appendChild(newRow);
            bindRow(newRow);
            updateTotal();
        });
    }
})();
