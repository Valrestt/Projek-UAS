-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Jun 2026 pada 05.04
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_sales_order`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_order`
--

CREATE TABLE `detail_order` (
  `id_detail` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga_satuan` decimal(15,2) NOT NULL,
  `subtotal` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `detail_order`
--

INSERT INTO `detail_order` (`id_detail`, `id_order`, `id_produk`, `jumlah`, `harga_satuan`, `subtotal`) VALUES
(1, 1, 1, 1, '8500000.00', '8500000.00'),
(2, 1, 3, 1, '2100000.00', '2100000.00'),
(3, 2, 2, 2, '1650000.00', '3300000.00'),
(4, 3, 4, 1, '450000.00', '450000.00'),
(5, 4, 3, 1, '2100000.00', '2100000.00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(11) NOT NULL,
  `nama_pelanggan` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `alamat` text COLLATE utf8mb4_unicode_ci,
  `no_telp` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `alamat`, `no_telp`, `created_at`, `updated_at`) VALUES
(1, '4Manz', 'Jl. Merdeka No. 10, Tangerang', '081234567890', '2026-05-29 09:48:33', '2026-06-21 14:08:38'),
(2, 'Ipung', 'Jl. Sudirman No. 22, Jakarta', '082112223333', '2026-05-29 09:48:33', '2026-06-21 14:08:08'),
(3, 'Aleng', 'Jl. Gatot Subroto No. 5, Bekasi', '087788899900', '2026-05-29 09:48:33', '2026-06-21 14:07:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `kode_produk` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nama_produk` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `harga` decimal(15,2) NOT NULL DEFAULT '0.00',
  `stok` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `kode_produk`, `nama_produk`, `harga`, `stok`, `created_at`, `updated_at`) VALUES
(1, 'ELK-001', 'Laptop Lenovo ThinkPad', '8500000.00', 20, '2026-05-29 09:48:33', '2026-05-29 09:48:33'),
(2, 'ELK-002', 'Printer Canon Inkjet', '1650000.00', 30, '2026-05-29 09:48:33', '2026-05-29 09:48:33'),
(3, 'ELK-003', 'Monitor LED 24 Inch', '2100000.00', 24, '2026-05-29 09:48:33', '2026-06-21 14:00:59'),
(4, 'ELK-004', 'Keyboard Mechanical', '450000.00', 39, '2026-05-29 09:48:33', '2026-05-29 09:52:06'),
(5, 'ELK-005', 'Mouse Wireless', '150000.00', 50, '2026-05-29 09:48:33', '2026-05-29 09:48:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sales_order`
--

CREATE TABLE `sales_order` (
  `id_order` int(11) NOT NULL,
  `no_order` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_sales` int(11) NOT NULL,
  `id_pelanggan` int(11) NOT NULL,
  `tanggal_order` date NOT NULL,
  `total_harga` decimal(15,2) NOT NULL DEFAULT '0.00',
  `status` enum('draft','dikirim','selesai','dibatalkan') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sales_order`
--

INSERT INTO `sales_order` (`id_order`, `no_order`, `id_sales`, `id_pelanggan`, `tanggal_order`, `total_harga`, `status`, `created_at`, `updated_at`) VALUES
(1, 'SO-20260529-0001', 2, 1, '2026-05-29', '10600000.00', 'selesai', '2026-05-29 09:48:33', '2026-05-29 09:48:33'),
(2, 'SO-20260529-0002', 2, 2, '2026-05-29', '3300000.00', 'dikirim', '2026-05-29 09:48:33', '2026-05-29 09:48:33'),
(3, 'SO-20260529-0003', 2, 1, '2026-05-29', '450000.00', 'draft', '2026-05-29 09:52:06', '2026-05-29 09:52:06'),
(4, 'SO-20260621-0001', 2, 1, '2026-06-21', '2100000.00', 'draft', '2026-06-21 14:00:59', '2026-06-21 14:00:59');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sales_person`
--

CREATE TABLE `sales_person` (
  `id_sales` int(11) NOT NULL,
  `nama` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('Admin','Sales','Manager') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Sales',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `sales_person`
--

INSERT INTO `sales_person` (`id_sales`, `nama`, `username`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'Mukmin', 'admin', '$2y$12$9jY8.tYrCuZeFFcr4ehNeOmuKWphqvcvxulEbpQCJwBmgE4dyRgti', 'Admin', '2026-05-29 09:48:33', '2026-06-21 14:07:29'),
(2, 'Fateh', 'sales', '$2y$12$OqBoBuEvWRcTMewxnmsvVe5OSggx3WuTCTmlGh5eznBTsZdZkRZG.', 'Sales', '2026-05-29 09:48:33', '2026-06-21 14:06:41'),
(3, 'Valrest', 'manager', '$2y$12$OrfqX5ieOJ.nGwTlXpeBX.ETMOGDwwmTtTE/E8NkDhr4avo8uLFEW', 'Manager', '2026-05-29 09:48:33', '2026-06-21 14:06:09');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detail_order`
--
ALTER TABLE `detail_order`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_detail_order` (`id_order`),
  ADD KEY `fk_detail_produk` (`id_produk`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`),
  ADD UNIQUE KEY `kode_produk` (`kode_produk`);

--
-- Indeks untuk tabel `sales_order`
--
ALTER TABLE `sales_order`
  ADD PRIMARY KEY (`id_order`),
  ADD UNIQUE KEY `no_order` (`no_order`),
  ADD KEY `fk_order_sales` (`id_sales`),
  ADD KEY `fk_order_pelanggan` (`id_pelanggan`);

--
-- Indeks untuk tabel `sales_person`
--
ALTER TABLE `sales_person`
  ADD PRIMARY KEY (`id_sales`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_order`
--
ALTER TABLE `detail_order`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `sales_order`
--
ALTER TABLE `sales_order`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `sales_person`
--
ALTER TABLE `sales_person`
  MODIFY `id_sales` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detail_order`
--
ALTER TABLE `detail_order`
  ADD CONSTRAINT `fk_detail_order` FOREIGN KEY (`id_order`) REFERENCES `sales_order` (`id_order`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detail_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `sales_order`
--
ALTER TABLE `sales_order`
  ADD CONSTRAINT `fk_order_pelanggan` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_order_sales` FOREIGN KEY (`id_sales`) REFERENCES `sales_person` (`id_sales`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
